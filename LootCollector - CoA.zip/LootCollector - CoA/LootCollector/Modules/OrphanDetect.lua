local L = LootCollector
local OrphanDetect = L:NewModule("OrphanDetect", "AceEvent-3.0")

local time = time

local function constants() return L:GetModule("Constants", true) end

-- Minimum wall-clock gap required before another session can be counted
-- (measured from the last counted session, not from an actual relog) --
-- this stops rapid relogging, or one long continuous session, from
-- fast-tracking an item to orphan status.
local SESSION_SPACING = 6 * 3600

local reportedThisSession = {}
local reportBudget = nil

function OrphanDetect:OnEnable()
    L:ScheduleAfter(90, function() OrphanDetect:ScanNow() end)
    self:ScheduleRepeatingScan()
end

function OrphanDetect:ScheduleRepeatingScan()
    L:ScheduleAfter(1800, function()
        OrphanDetect:ScanNow()
        OrphanDetect:ScheduleRepeatingScan()
    end)
end

function OrphanDetect:ScanNow()
    local C = constants()
    if not (L.db and L.db.global) then return end
    L.db.global.orphanTracker = L.db.global.orphanTracker or {}
    local tracker = L.db.global.orphanTracker
    local now = time()
    if reportBudget == nil then
        reportBudget = (C and C.ORPHAN_MAX_REPORTS_PER_SESSION) or 10
    end
    local minSessions = (C and C.ORPHAN_MIN_SESSIONS) or 3
    local minAge = ((C and C.ORPHAN_MIN_AGE_DAYS) or 7) * 86400

    local db = L:GetDiscoveriesDB()
    if not db then return end

    -- id -> true once we've updated the tracker for id this scan (guards
    -- against redoing the tracker update for every one of an id's records).
    local unresolvedSet = {}
    -- id -> true for ids that currently qualify as matured orphans.
    local orphanSet = {}
    -- id -> number of local discovery records seen this scan (for the
    -- report payload); only meaningful for ids in unresolvedSet.
    local counts = {}
    local anyChange = false

    -- Single pass over every discovery record: identifies distinct
    -- unresolved item IDs, updates the session tracker and orphanSet the
    -- first time each such ID is seen, then syncs THIS record's rec.orphan
    -- flag to the (by-then-known) desired value. Cost is O(records in DB)
    -- per scan, independent of how many orphans have accumulated.
    for _, rec in pairs(db) do
        local id = tonumber(rec.i)
        local desired = false
        if id and id > 0 and not GetItemInfo(id) then
            counts[id] = (counts[id] or 0) + 1
            if not unresolvedSet[id] then
                unresolvedSet[id] = true
                local tr = tracker[id]
                if not tr then
                    tracker[id] = { fs = now, sc = 1, lss = now }
                else
                    if (now - (tr.lss or 0)) >= SESSION_SPACING then
                        tr.sc = (tr.sc or 1) + 1
                        tr.lss = now
                    end
                    if (tr.sc or 0) >= minSessions and (now - (tr.fs or now)) >= minAge then
                        orphanSet[id] = true
                    end
                end
            end
            desired = orphanSet[id] or false
        end
        -- else: id is missing/invalid, or GetItemInfo resolves it -> not an
        -- orphan (desired stays false), which rehabilitates any stale flag.
        if (rec.orphan or false) ~= desired then
            rec.orphan = desired or nil
            anyChange = true
        end
    end

    -- Broadcast pass: bounded by the number of matured orphans this scan,
    -- not by DB size. At most one broadcast per item per session, and at
    -- most reportBudget broadcasts per session overall.
    for id in pairs(orphanSet) do
        if not reportedThisSession[id] and reportBudget > 0 then
            if L.db.profile and not L.db.profile.orphanHelpShown then
                -- Unconditional chat delivery (does not depend on
                -- db.profile.toasts.enabled), formatted after the
                -- newer-version notice in Comm.lua. The flag is set only
                -- once this print has actually gone out, so the one-shot
                -- latch is never consumed by a delivery nobody saw.
                print("|cff00ff00LootCollector:|r Some items appear to have |cffff3333vanished|r from the game and are now hidden.")
                print("|cff00ff00LootCollector:|r Right-click a pin and choose |cffff7f00Report as Gone|r to help everyone.")
                L.db.profile.orphanHelpShown = true

                -- Best-effort enhancement for players who have toasts
                -- enabled; the chat lines above are the message of record.
                local Toast = L:GetModule("Toast", true)
                if Toast and Toast.ShowSpecialMessage then
                    Toast:ShowSpecialMessage("Interface\\Icons\\INV_Misc_QuestionMark",
                        "Some items look |cffff3333vanished|r from the game",
                        "They are hidden. Right-click a pin > Report as Gone helps everyone.")
                end
            end
            local Comm = L:GetModule("Comm", true)
            if Comm and Comm.BroadcastOrphanReport then
                Comm:BroadcastOrphanReport(id, counts[id] or 1)
                reportedThisSession[id] = true
                reportBudget = reportBudget - 1
            end
        end
    end

    -- Rehabilitation bookkeeping: item resolves again -> drop its tracker
    -- entry. Bounded by the number of tracked ids, not by DB size.
    for id in pairs(tracker) do
        if not unresolvedSet[id] then
            tracker[id] = nil
        end
    end

    if anyChange then
        L:SendMessage("LootCollector_DiscoveriesUpdated", "bulk")
    end
end

return OrphanDetect

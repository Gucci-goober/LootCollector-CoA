local L = LootCollector
local UpdateNotice = L:NewModule("UpdateNotice", "AceEvent-3.0")

-- Download page. Modules/Constants.lua is the single source of truth for
-- the URL.
local banner, urlBox

local function updateURL()
    local Constants = L:GetModule("Constants", true)
    return Constants and Constants.KAMILABS_URL or ""
end

-- Both the banner and the URL box live in the same 16px-tall band at the
-- bottom of the Viewer window: from the window's backdrop inset (4px, see
-- Viewer.lua's window:SetBackdrop insets) up to the pagination bar, which
-- is anchored at ("BOTTOM", 0, 20) (Viewer.lua ~4284). That leaves exactly
-- [4, 20] free, so both controls anchor BOTTOMLEFT/BOTTOMRIGHT at y=4 with
-- height 16 - flush against the border below and the pagination bar above,
-- with no overlap either way.
local BAND_HEIGHT = 16
local BAND_Y = 4

-- Creates the banner button and URL EditBox as children of the Viewer
-- window the first time it exists. Safe to call repeatedly; only builds
-- once (subsequent calls just return the cached banner).
local function ensureBanner()
    local window = _G["LootCollectorViewerWindow"]
    if not window or banner then return banner end

    banner = CreateFrame("Button", nil, window)
    banner:SetHeight(BAND_HEIGHT)
    banner:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 16, BAND_Y)
    banner:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -16, BAND_Y)
    banner:SetFrameLevel(window:GetFrameLevel() + 10)

    banner.text = banner:CreateFontString(nil, "OVERLAY")
    banner.text:SetFont("Fonts\\FRIZQT__.TTF", 10, "")
    banner.text:SetPoint("CENTER")
    banner.text:SetTextColor(1.0, 0.82, 0.0)

    urlBox = CreateFrame("EditBox", nil, window, "InputBoxTemplate")
    urlBox:SetHeight(BAND_HEIGHT)
    urlBox:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 24, BAND_Y)
    urlBox:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -24, BAND_Y)
    urlBox:SetFrameLevel(window:GetFrameLevel() + 11)
    urlBox:SetAutoFocus(false)
    urlBox:Hide()

    urlBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        self:Hide()
        banner:Show()
    end)
    urlBox:SetScript("OnEditFocusLost", function(self)
        self:Hide()
        if L.newerVersionSeen then banner:Show() end
    end)
    urlBox:SetScript("OnTextChanged", function(self)
        -- Keep the URL intact whatever the user types or pastes. SetText
        -- re-fires OnTextChanged, but the re-entrant call's GetText() now
        -- equals updateURL(), so the condition is false and it returns
        -- immediately - one extra call, never unbounded recursion.
        if self:GetText() ~= updateURL() then
            self:SetText(updateURL())
            self:HighlightText()
        end
    end)

    banner:SetScript("OnClick", function()
        banner:Hide()
        urlBox:SetText(updateURL())
        urlBox:Show()
        urlBox:SetFocus()
        urlBox:HighlightText()
    end)

    banner:Hide()
    return banner
end

function UpdateNotice:Refresh()
    local b = ensureBanner()
    if not b then return end
    local url = updateURL()
    if L.newerVersionSeen and url ~= "" then
        local label = string.format("New version %s available - click here for the download link", L.newerVersionSeen)
        b.text:SetText(label)
        b:Show()
    else
        b:Hide()
        if urlBox then urlBox:Hide() end
    end
end

-- Hooks the Viewer window's OnShow the moment it exists, instead of
-- polling on a repeating timer: the Viewer window is created lazily by
-- Viewer:CreateWindow() (called from Viewer:Show()), so hooking that
-- method fires exactly once, right when the window is actually built -
-- no wasted ticks for players who never open the Viewer this session.
local function hookWindow(window)
    if not window or window.lcUpdateNoticeHooked then return end
    window.lcUpdateNoticeHooked = true
    window:HookScript("OnShow", function() UpdateNotice:Refresh() end)
    UpdateNotice:Refresh()
end

function UpdateNotice:OnEnable()
    self:RegisterMessage("LootCollector_NewerVersion", function() UpdateNotice:Refresh() end)

    -- Covers the (unlikely at OnEnable time) case where the window already
    -- exists, and installs the hook for the normal case where it doesn't.
    hookWindow(_G["LootCollectorViewerWindow"])

    local Viewer = L:GetModule("Viewer", true)
    if Viewer and Viewer.CreateWindow then
        hooksecurefunc(Viewer, "CreateWindow", function(self) hookWindow(self.window) end)
    end
end

return UpdateNotice

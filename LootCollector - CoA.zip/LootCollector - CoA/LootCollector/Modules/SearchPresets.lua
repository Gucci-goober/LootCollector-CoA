-- SearchPresets: save/restore full Viewer search states in one click.
-- Data layer here; the dropdown menu UI is appended by Task 4 below the marker.
local L = LootCollector
local SearchPresets = L:NewModule("SearchPresets")

local function trim(s)
    s = tostring(s or "")
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function deepCopy(src)
    if type(src) ~= "table" then return src end
    local t = {}
    for k, v in pairs(src) do t[k] = deepCopy(v) end
    return t
end

function SearchPresets:EnsureDB()
    if not (L.db and L.db.profile) then return nil end
    if not L.db.profile.searchPresets then
        L.db.profile.searchPresets = {}
    end
    return L.db.profile.searchPresets
end

function SearchPresets:GetPresets()
    return self:EnsureDB() or {}
end

function SearchPresets:SeedDefaults()
    local presets = self:EnsureDB()
    if not presets then return end
    if L.db.profile.searchPresetsSeeded then return end
    if #presets == 0 then
        table.insert(presets, { name = "Parade", state = {
            searchTerm = "Parry", searchTooltipsEnabled = true,
            minReqLevel = 1, maxReqLevel = 80, currentFilter = "eq",
        }})
        table.insert(presets, { name = "Esquive", state = {
            searchTerm = "Dodge", searchTooltipsEnabled = true,
            minReqLevel = 1, maxReqLevel = 80, currentFilter = "eq",
        }})
    end
    L.db.profile.searchPresetsSeeded = true
end

function SearchPresets:SavePreset(name, state)
    local presets = self:EnsureDB()
    if not presets then return nil end
    name = trim(name)
    if name == "" or type(state) ~= "table" then return nil end
    local copy = deepCopy(state)
    for i, p in ipairs(presets) do
        if p.name == name then
            p.state = copy
            return i
        end
    end
    table.insert(presets, { name = name, state = copy })
    return #presets
end

function SearchPresets:RenamePreset(index, newName)
    local presets = self:EnsureDB()
    local p = presets and presets[index]
    if not p then return false end
    newName = trim(newName)
    if newName == "" then return false end
    for i, other in ipairs(presets) do
        if other.name == newName and i ~= index then return false end
    end
    p.name = newName
    return true
end

function SearchPresets:DeletePreset(index)
    local presets = self:EnsureDB()
    if not (presets and presets[index]) then return false end
    table.remove(presets, index)
    return true
end

function SearchPresets:ApplyPreset(index)
    local presets = self:EnsureDB()
    local p = presets and presets[index]
    if not p then return false end
    local Viewer = L:GetModule("Viewer", true)
    if not (Viewer and Viewer.ApplySearchState) then return false end
    Viewer:ApplySearchState(deepCopy(p.state))
    return true
end

-- ===== DATA API END - menu UI appended by Task 4 =====

StaticPopupDialogs["LOOTCOLLECTOR_SAVE_PRESET"] = {
    text = "Save current search as:",
    button1 = "Save",
    button2 = "Cancel",
    hasEditBox = true,
    maxLetters = 40,
    OnAccept = function(dialog)
        local editBox = _G[dialog:GetName() .. "EditBox"]
        local name = editBox and editBox:GetText() or ""
        local Viewer = L:GetModule("Viewer", true)
        if Viewer and Viewer.CaptureSearchState then
            SearchPresets:SavePreset(name, Viewer:CaptureSearchState())
        end
    end,
    EditBoxOnEnterPressed = function(editBox)
        local dialog = editBox:GetParent()
        StaticPopupDialogs["LOOTCOLLECTOR_SAVE_PRESET"].OnAccept(dialog)
        dialog:Hide()
    end,
    EditBoxOnEscapePressed = function(editBox) editBox:GetParent():Hide() end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

StaticPopupDialogs["LOOTCOLLECTOR_RENAME_PRESET"] = {
    text = "Rename preset '%s' to:",
    button1 = "Rename",
    button2 = "Cancel",
    hasEditBox = true,
    maxLetters = 40,
    OnAccept = function(dialog, data)
        local editBox = _G[dialog:GetName() .. "EditBox"]
        if data and editBox then
            SearchPresets:RenamePreset(data, editBox:GetText())
        end
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

function SearchPresets:OpenMenu(anchor)
    local Viewer = L:GetModule("Viewer", true)
    if not (Viewer and Viewer._CreateContextMenu) then return end
    self:SeedDefaults()
    local presets = self:GetPresets()
    local buttons = {}
    for i, p in ipairs(presets) do
        table.insert(buttons, { text = p.name, onClick = function()
            SearchPresets:ApplyPreset(i)
        end })
    end
    table.insert(buttons, { text = "+ Save current search...", onClick = function()
        StaticPopup_Show("LOOTCOLLECTOR_SAVE_PRESET")
    end })
    if #presets > 0 then
        table.insert(buttons, { text = "Manage...", onClick = function()
            SearchPresets:OpenManageMenu(anchor)
        end })
    end
    Viewer._CreateContextMenu(anchor, "Search Presets", buttons)
end

function SearchPresets:OpenManageMenu(anchor)
    local Viewer = L:GetModule("Viewer", true)
    if not (Viewer and Viewer._CreateContextMenu) then return end
    local buttons = {}
    for i, p in ipairs(self:GetPresets()) do
        table.insert(buttons, { text = "Rename: " .. p.name, onClick = function()
            local dialog = StaticPopup_Show("LOOTCOLLECTOR_RENAME_PRESET", p.name)
            if dialog then dialog.data = i end
        end })
        table.insert(buttons, { text = "Delete: " .. p.name, onClick = function()
            SearchPresets:DeletePreset(i)
        end })
    end
    Viewer._CreateContextMenu(anchor, "Manage Presets", buttons)
end

-- ===== TEMPORARY DEBUG LOG VIEWER (/lcdbg) - remove before shipping =====
-- Shows L.db.profile.debugLog (populated by the LC-DBG probes in Viewer.lua)
-- in a copyable multiline EditBox so it can be pasted out of the game.

local function LCDBG_EnsureFrame()
    if LootCollectorDebugLogFrame then return LootCollectorDebugLogFrame end

    local f = CreateFrame("Frame", "LootCollectorDebugLogFrame", UIParent)
    f:SetSize(620, 480)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    f:Hide()

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -15)
    title:SetText("LootCollector Debug Log  (/lcdbg clear to wipe)")

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -5, -5)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    local scrollFrame = CreateFrame("ScrollFrame", "LootCollectorDebugLogScrollFrame", f, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 16, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", -32, 16)

    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(544)
    editBox:SetAutoFocus(false)
    editBox:SetScript("OnEscapePressed", function(box) box:ClearFocus() end)
    scrollFrame:SetScrollChild(editBox)

    f.editBox = editBox
    f.scrollFrame = scrollFrame
    LootCollectorDebugLogFrame = f
    return f
end

local function LCDBG_ShowLog()
    local f = LCDBG_EnsureFrame()
    local lines = (L.db and L.db.profile and L.db.profile.debugLog) or {}
    f.editBox:SetText(table.concat(lines, "\n"))
    f:Show()
    f.editBox:SetFocus()
    f.editBox:HighlightText()
end

-- Guarded: the headless pytest/lupa harness loads this file without the
-- WoW client's SlashCmdList global defined, so skip registration there.
if SlashCmdList then
    SLASH_LCDBG1 = "/lcdbg"
    SlashCmdList["LCDBG"] = function(msg)
        local cmd = string.lower(tostring(msg or ""))
        if cmd == "clear" then
            if L.db and L.db.profile then
                L.db.profile.debugLog = {}
            end
            print("|cffff00ffLC-DBG|r debug log cleared")
        elseif cmd == "dump" then
            print("|cffff00ffLC-DBG|r flushing log to SavedVariables...")
            ReloadUI()
        elseif cmd == "export" then
            -- Writes the full canonical export string (same format as the
            -- Import/Export panel) into SavedVariables so it can be read
            -- from outside the game and baked into LootCollector_StarterDB.
            local IE = L.GetModule and L:GetModule("ImportExport", true)
            if not (IE and IE.ExportString) then
                print("|cffff00ffLC-DBG|r ImportExport module not available")
                return
            end
            local s, err = IE:ExportString(false)
            if not s then
                print("|cffff00ffLC-DBG|r export failed: " .. tostring(err))
                return
            end
            if L.db and L.db.profile then
                L.db.profile.starterExport = s
                print(string.format("|cffff00ffLC-DBG|r export ready (%d chars), flushing to SavedVariables...", string.len(s)))
                ReloadUI()
            end
        else
            LCDBG_ShowLog()
        end
    end
end
-- ===== END TEMPORARY DEBUG LOG VIEWER =====

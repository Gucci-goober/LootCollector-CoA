-- StatFilter: checkbox stat filter for the Discoveries window.
-- Catalog + pure matching logic first; the panel UI is built lazily in
-- TogglePanel so this file stays loadable in the headless test harness.
local L = LootCollector
local StatFilter = L:NewModule("StatFilter")

-- Ordered categories. Patterns are lowercase substrings searched in the
-- tooltip cache text (Scanner.lua lowercases it at hydration time).
StatFilter.CATEGORIES = {
    { name = "Attributes", stats = {
        { key = "strength",  label = "Strength",  patterns = { "strength" } },
        { key = "agility",   label = "Agility",   patterns = { "agility" } },
        { key = "stamina",   label = "Stamina",   patterns = { "stamina" } },
        { key = "intellect", label = "Intellect", patterns = { "intellect" } },
        { key = "spirit",    label = "Spirit",    patterns = { "spirit" } },
    }},
    { name = "Defense", stats = {
        { key = "defense",    label = "Defense",    patterns = { "defense rating", "increases defense" } },
        { key = "dodge",      label = "Dodge",      patterns = { "dodge" } },
        { key = "parry",      label = "Parry",      patterns = { "parry" } },
        { key = "block",      label = "Block",      patterns = { "block rating", "block value", "shield block" } },
        { key = "resilience", label = "Resilience", patterns = { "resilience" } },
    }},
    { name = "Melee / Ranged", stats = {
        { key = "attackpower", label = "Attack Power",      patterns = { "attack power" } },
        { key = "hit",         label = "Hit",               patterns = { "hit rating" } },
        { key = "crit",        label = "Critical Strike",   patterns = { "critical strike" } },
        { key = "haste",       label = "Haste",             patterns = { "haste" } },
        { key = "expertise",   label = "Expertise",         patterns = { "expertise" } },
        { key = "armorpen",    label = "Armor Penetration", patterns = { "armor penetration" } },
    }},
    { name = "Spell", stats = {
        { key = "spellpower", label = "Spell Power",       patterns = { "spell power" } },
        { key = "spellhit",   label = "Spell Hit",         patterns = { "spell hit" } },
        { key = "spellcrit",  label = "Spell Crit",        patterns = { "spell critical" } },
        { key = "spellpen",   label = "Spell Penetration", patterns = { "spell penetration" } },
        { key = "mp5",        label = "Mana per 5",        patterns = { "mana per 5" } },
    }},
}

local PATTERNS_BY_KEY = {}
for _, cat in ipairs(StatFilter.CATEGORIES) do
    for _, stat in ipairs(cat.stats) do
        PATTERNS_BY_KEY[stat.key] = stat.patterns
    end
end
StatFilter.PATTERNS_BY_KEY = PATTERNS_BY_KEY

function StatFilter.HasSelection(selected)
    return selected ~= nil and next(selected) ~= nil
end

function StatFilter.CountSelected(selected)
    local n = 0
    if selected then
        for _ in pairs(selected) do n = n + 1 end
    end
    return n
end

-- OR semantics: passes if the tooltip contains any pattern of any selected
-- stat. Empty selection passes everything; a selection with no hydrated
-- tooltip excludes the row (the post-hydration refresh completes the list).
function StatFilter.Matches(tooltipText, selected)
    if not StatFilter.HasSelection(selected) then return true end
    if not tooltipText then return false end
    for key in pairs(selected) do
        local patterns = PATTERNS_BY_KEY[key]
        if patterns then
            for _, pat in ipairs(patterns) do
                if string.find(tooltipText, pat, 1, true) then
                    return true
                end
            end
        end
    end
    return false
end

-- Profile-backed selection set. Callers mutate the returned table in place
-- so persistence is automatic.
function StatFilter:GetSelected()
    if not (L.db and L.db.profile) then return {} end
    if not L.db.profile.statFilter then L.db.profile.statFilter = {} end
    return L.db.profile.statFilter
end

-- ===== Panel UI (lazily built; never executed in the headless harness) =====

local panel

local function refreshViewer()
    local Viewer = L:GetModule("Viewer", true)
    if not Viewer then return end
    Viewer.currentPage = 1
    if Viewer.RefreshData then Viewer:RefreshData() end
    if Viewer.UpdateFilterButtonStates then Viewer:UpdateFilterButtonStates() end
end

local function buildPanel()
    local f = CreateFrame("Frame", "LootCollectorStatFilterFrame", UIParent)
    f:SetSize(390, 380)
    f:SetFrameStrata("DIALOG")
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    f:EnableMouse(true)
    f:Hide()
    table.insert(UISpecialFrames, "LootCollectorStatFilterFrame")

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -16)
    title:SetText("Stat Filter")

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -6, -6)

    f.checks = {}
    -- Two columns: categories 1-2 left, 3-4 right.
    local colX = { 18, 200 }
    local colForCat = { 1, 1, 2, 2 }
    local colY = { -40, -40 }
    for ci, cat in ipairs(StatFilter.CATEGORIES) do
        local col = colForCat[ci]
        local x = colX[col]
        local header = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        header:SetPoint("TOPLEFT", x, colY[col])
        header:SetText(cat.name)
        header:SetTextColor(1, 0.8, 0.2)
        colY[col] = colY[col] - 20
        for _, stat in ipairs(cat.stats) do
            local cb = CreateFrame("CheckButton",
                "LootCollectorStatFilterCheck_" .. stat.key, f, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("TOPLEFT", x, colY[col] + 2)
            -- Explicit label FontString: the codebase's established pattern for
            -- UICheckButtonTemplate (no reliance on a $parentText region).
            local label = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            label:SetPoint("LEFT", cb, "RIGHT", 2, 0)
            label:SetText(stat.label)
            cb.statKey = stat.key
            cb:SetScript("OnClick", function(self)
                local selected = StatFilter:GetSelected()
                if self:GetChecked() then
                    selected[self.statKey] = true
                else
                    selected[self.statKey] = nil
                end
                refreshViewer()
            end)
            f.checks[stat.key] = cb
            colY[col] = colY[col] - 22
        end
        colY[col] = colY[col] - 10
    end

    local clearBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    clearBtn:SetSize(80, 22)
    clearBtn:SetPoint("BOTTOM", 0, 16)
    clearBtn:SetText("Clear")
    clearBtn:SetScript("OnClick", function()
        local selected = StatFilter:GetSelected()
        for k in pairs(selected) do selected[k] = nil end
        StatFilter:UpdateChecks()
        refreshViewer()
    end)

    return f
end

-- Sync every checkbox with the current selection (no-op before first open).
function StatFilter:UpdateChecks()
    if not panel then return end
    local selected = self:GetSelected()
    for key, cb in pairs(panel.checks) do
        cb:SetChecked(selected[key] and true or false)
    end
end

function StatFilter:TogglePanel(anchor)
    if panel and panel:IsShown() then
        panel:Hide()
        return
    end
    if not panel then panel = buildPanel() end
    panel:ClearAllPoints()
    if anchor then
        panel:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, -4)
    else
        panel:SetPoint("CENTER")
    end
    self:UpdateChecks()
    panel:Show()
end



local L = LootCollector
local Settings = L:NewModule("Settings", "AceConsole-3.0")
local AceConfig = (LibStub and LibStub("AceConfig-3.0", true)) or nil
local AceConfigDialog = (LibStub and LibStub("AceConfigDialog-3.0", true)) or nil

local function OpenCopyPopup(title, textToCopy)
    local f = _G["LootCollectorCopyPopup"]
    if not f then
        f = CreateFrame("Frame", "LootCollectorCopyPopup", UIParent)
        f:SetSize(560, 380)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetMovable(true)
        f:EnableMouse(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f:SetBackdrop({
            bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
            edgeFile = "Interface\\DialogBox\\UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = {left = 8, right = 8, top = 8, bottom = 8},
        })
        f:SetBackdropColor(0, 0, 0, 1)

        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f.title:SetPoint("TOPLEFT", 16, -12)

        f.scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        f.scroll:SetPoint("TOPLEFT", 16, -36)
        f.scroll:SetPoint("BOTTOMRIGHT", -34, 48)

        f.edit = CreateFrame("EditBox", nil, f.scroll)
        f.edit:SetMultiLine(true)
        f.edit:SetFontObject(ChatFontNormal)
        f.edit:SetWidth(500)
        f.edit:SetAutoFocus(false)
        f.edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        f.edit:EnableMouse(true)
		f.edit:SetScript("OnTextChanged", function() end)
		f.edit:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
        f.scroll:SetScrollChild(f.edit)

        f.btnClose = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        f.btnClose:SetSize(100, 22)
        f.btnClose:SetPoint("BOTTOMRIGHT", -12, 12)
        f.btnClose:SetText("Close")
        f.btnClose:SetScript("OnClick", function() f:Hide() end)
        
        _G["LootCollectorCopyPopup"] = f
    end

    f.title:SetText(title)
    f.edit:SetText(textToCopy)
    f:Show()
    f.edit:SetFocus()
end

local function refreshUI()
	local Map = L:GetModule("Map", true)
	if Map then
        
        Map.cacheIsDirty = true
        
        if Map.Update and WorldMapFrame and WorldMapFrame:IsShown() then
            Map:Update()
        end
        
        if Map.UpdateMinimap then
            Map:UpdateMinimap() 
        end
    end
    
	local Arrow = L:GetModule("Arrow", true)
	if Arrow and Arrow.frame and L.db and L.db.profile and L.db.profile.mapFilters then
		local mf = L.db.profile.mapFilters
		if mf.hideAll or (mf.hideWorldMap and mf.hideMinimap) then
			Arrow.frame:Hide()
		end
	end
end

local function ShowTopContributors()
    
	local discoveries = L:GetDiscoveriesDB()
	if not discoveries then
		print("|cffff7f00LootCollector|r Database not found.")
		return
	end
	local counts = {}
	for _, d in pairs(discoveries) do
		if d and d.fp and d.fp ~= "" and d.fp ~= "Unknown" then
			counts[d.fp] = (counts[d.fp] or 0) + 1
		end
	end
	local sorted = {}
	for n, c in pairs(counts) do
		table.insert(sorted, {n = n, c = c})
	end
	table.sort(sorted, function(a, b) return a.c > b.c end)
	print("|cffffff00--- LootCollector Top Contributors ---|r")
	for i = 1, math.min(10, #sorted) do
		print(string.format("%d. |cffffff00%s|r: %d discoveries", i, sorted[i].n, sorted[i].c))
	end
end

local function listToString(t)
	if type(t) ~= "table" then return "" end
	local names = {}
	for name, on in pairs(t) do
		if on and type(name) == "string" then
			local s = name:gsub("^%s+", ""):gsub("%s+$", "")
			if s ~= "" then table.insert(names, s) end
		end
	end
	table.sort(names)
	return table.concat(names, "\n")
end

local function stringToList(v, t)
	if type(t) ~= "table" then return end
	for k in pairs(t) do t[k] = nil end
	if type(v) ~= "string" then return end
	for line in v:gmatch("[^\r\n]+") do
		local s = line:gsub("^%s+", ""):gsub("%s+$", "")
		if s ~= "" then t[s] = true end
	end
end

local function ensureDefaults()
	if not L.db and L.db.profile then return end
	local p = L.db.profile
	
	if p.hidePlayerNames == nil then p.hidePlayerNames = false end
	if p.hideNonEssential == nil then p.hideNonEssential = false end
	if p.disableMysticScrolls == nil then p.disableMysticScrolls = false end
    
    p.featureOverrides = p.featureOverrides or {
        realmType = "AUTO",
    }
    
    p.viewer = p.viewer or {}
    if p.viewer.rowFont == nil then p.viewer.rowFont = "Fonts\\ARIALN.TTF" end
    if p.viewer.rowFontSize == nil then p.viewer.rowFontSize = 14 end
    if p.viewer.rowHeight == nil then p.viewer.rowHeight = 28 end
    if p.viewer.uiFont == nil then p.viewer.uiFont = "Fonts\\ARIALN.TTF" end
    if p.viewer.uiFontSize == nil then p.viewer.uiFontSize = 13 end
    if p.viewer.useWCAGColoring == nil then p.viewer.useWCAGColoring = true end
    if p.viewer.inlineVendorView == nil then p.viewer.inlineVendorView = false end
    if p.viewer.splitRatio == nil then p.viewer.splitRatio = 0.64 end
    if p.viewer.asyncLoading == nil then p.viewer.asyncLoading = true end
    if p.viewer.animatedBorder == nil then p.viewer.animatedBorder = true end
    
	p.sharing = p.sharing or {}
	if p.sharing.enabled == nil then p.sharing.enabled = true end
	if p.sharing.anonymous == nil then p.sharing.anonymous = false end
	if p.sharing.delayed == nil then p.sharing.delayed = false end
	if p.sharing.delaySeconds == nil then p.sharing.delaySeconds = 30 end
	if p.sharing.pauseInHighRisk == nil then p.sharing.pauseInHighRisk = false end
    if p.sharing.allowShowRequests == nil then p.sharing.allowShowRequests = true end 
	if p.sharing.rejectPartySync == nil then p.sharing.rejectPartySync = false end
	if p.sharing.rejectGuildSync == nil then p.sharing.rejectGuildSync = false end
	if p.sharing.rejectWhisperSync == nil then p.sharing.rejectWhisperSync = false end
	if p.sharing.blockList == nil then p.sharing.blockList = {} end
	if p.sharing.whiteList == nil then p.sharing.whiteList = {} end
	if p.autoCache == nil then p.autoCache = true end
	if p.lootedScope ~= "character" and p.lootedScope ~= "account" then
		p.lootedScope = "account"
	end

	p.toasts = p.toasts or {}
	if p.toasts.enabled == nil then p.toasts.enabled = false end
	if p.toasts.displayTime == nil then p.toasts.displayTime = 5.0 end
	if p.toasts.tickerEnabled == nil then p.toasts.tickerEnabled = true end
	if p.toasts.tickerSpeed == nil then p.toasts.tickerSpeed = 90 end
	if p.toasts.tickerFontDelta == nil then p.toasts.tickerFontDelta = 3 end
	if p.toasts.tickerOutline == nil then p.toasts.tickerOutline = false end
	if p.toasts.whiteFrame == nil then p.toasts.whiteFrame = true end
	if p.toasts.toastOnlyNew == nil then p.toasts.toastOnlyNew = true end
	if p.toasts.toastMinQuality == nil then p.toasts.toastMinQuality = 2 end
    
    
    p.mapFilters = p.mapFilters or {}
    if p.mapFilters.showMapFilter == nil then p.mapFilters.showMapFilter = true end
    if p.mapFilters.showMinimap == nil then p.mapFilters.showMinimap = true end
    if p.mapFilters.hideWorldMap == nil then
        p.mapFilters.hideWorldMap = p.mapFilters.hideAll and true or false
    end
    if p.mapFilters.hideMinimap == nil then
        p.mapFilters.hideMinimap = (p.mapFilters.hideAll or p.mapFilters.showMinimap == false) and true or false
    end
    if p.mapFilters.hideMinimap then
        p.mapFilters.showMinimap = false
    end
    if p.mapFilters.maxMinimapDistance == nil then p.mapFilters.maxMinimapDistance = 0 end 
	if p.mapFilters.disableProximityList == nil then p.mapFilters.disableProximityList = false end 
	if p.minimapButtonHidden == nil then p.minimapButtonHidden = false end
	if p.mapFilters.pinSize == nil then p.mapFilters.pinSize = 24 end
	if p.mapFilters.minimapPinSize == nil then p.mapFilters.minimapPinSize = 16 end
	if p.mapFilters.showZoneSummaries == nil then p.mapFilters.showZoneSummaries = false end
	if p.mapFilters.disableFadeEffect == nil then p.mapFilters.disableFadeEffect = false end
	if p.mapFilters.rarityPinBorders == nil then p.mapFilters.rarityPinBorders = false end
	
    
    if not L.db.char then L.db.char = {} end
    local c = L.db.char

    -- 1.1.0: plain item icons. The old default painted a glow and a colored
    -- square on every pin. One-time flip so existing profiles pick that up;
    -- the toggle below can turn the glow back on.
    if not c.migratedCleanPinsV11 then
        p.mapFilters.rarityPinBorders = false
        c.migratedCleanPinsV11 = true
    end
    if not c.migratedPinSizeV11 then
        if (tonumber(p.mapFilters.pinSize) or 16) <= 16 then
            p.mapFilters.pinSize = 24
        end
        if (tonumber(p.mapFilters.minimapPinSize) or 10) <= 10 then
            p.mapFilters.minimapPinSize = 16
        end
        c.migratedPinSizeV11 = true
    end

    if not c.migratedFiltersV8 then
        c.mapFilters = {
            hideAll = p.mapFilters.hideAll or false,
            hideFaded = p.mapFilters.hideFaded or false,
            hideStale = p.mapFilters.hideStale or false,
            hideLooted = p.mapFilters.hideLooted or false,
            hideUnconfirmed = p.mapFilters.hideUnconfirmed or false,
            hideUncached = p.mapFilters.hideUncached or false,
            hideOrphans = p.mapFilters.hideOrphans ~= false,
            hideLearnedTransmog = p.mapFilters.hideLearnedTransmog or false,
            hideCollectedME = p.mapFilters.hideCollectedME or false,
            hideBags = p.mapFilters.hideBags or false,
            showMysticScrolls = p.mapFilters.showMysticScrolls ~= false,
            showWorldforged = p.mapFilters.showWorldforged ~= false,
            showVendors = p.mapFilters.showVendors ~= false,
            autoTrackNearest = p.mapFilters.autoTrackNearest or false,
            minRarity = p.mapFilters.minRarity or 0,
            usableByClasses = {},
            allowedEquipLoc = {},
        }
        
        if p.mapFilters.usableByClasses then
            for k, v in pairs(p.mapFilters.usableByClasses) do c.mapFilters.usableByClasses[k] = v end
        end
        if p.mapFilters.allowedEquipLoc then
            for k, v in pairs(p.mapFilters.allowedEquipLoc) do c.mapFilters.allowedEquipLoc[k] = v end
        end
        
        c.paused = p.paused or false
        c.autoPauseInBG = p.autoPauseInBG or false
        c.autoPauseInRaidInstance = p.autoPauseInRaidInstance or false
        c.autoPauseInRaidGroup = p.autoPauseInRaidGroup or false
        
        c.migratedFiltersV8 = true
    end
    
    c.mapFilters = c.mapFilters or {}
    if c.mapFilters.hideAll == nil then c.mapFilters.hideAll = false end
    if c.mapFilters.hideFaded == nil then c.mapFilters.hideFaded = false end
    if c.mapFilters.hideStale == nil then c.mapFilters.hideStale = false end
    if c.mapFilters.hideLooted == nil then c.mapFilters.hideLooted = false end
    if c.mapFilters.hideUnconfirmed == nil then c.mapFilters.hideUnconfirmed = false end
    if c.mapFilters.hideUncached == nil then c.mapFilters.hideUncached = false end
    if c.mapFilters.hideOrphans == nil then c.mapFilters.hideOrphans = true end
    if c.mapFilters.hideLearnedTransmog == nil then c.mapFilters.hideLearnedTransmog = false end
    if c.mapFilters.hideCollectedME == nil then c.mapFilters.hideCollectedME = false end
	if c.mapFilters.hideBags == nil then c.mapFilters.hideBags = false end
    if c.mapFilters.showMysticScrolls == nil then c.mapFilters.showMysticScrolls = true end
    if c.mapFilters.showWorldforged == nil then c.mapFilters.showWorldforged = true end
    if c.mapFilters.showVendors == nil then c.mapFilters.showVendors = true end
    if c.mapFilters.autoTrackNearest == nil then c.mapFilters.autoTrackNearest = false end
    if c.mapFilters.minRarity == nil then c.mapFilters.minRarity = 0 end
    if c.mapFilters.usableByClasses == nil then c.mapFilters.usableByClasses = {} end
    if c.mapFilters.allowedEquipLoc == nil then c.mapFilters.allowedEquipLoc = {} end
    
	if c.paused == nil then c.paused = false end
	if c.autoPauseInBG == nil then c.autoPauseInBG = false end
	if c.autoPauseInRaidInstance == nil then c.autoPauseInRaidInstance = false end
	if c.autoPauseInRaidGroup == nil then c.autoPauseInRaidGroup = false end
end

StaticPopupDialogs["LOOTCOLLECTOR_REALM_OVERRIDE_RELOAD"] = {
    text = "You have changed the Active Realm Mode.\n\nA UI reload is required to fully apply these changes to the interface.\n\nWould you like to reload now?",
    button1 = "Reload UI",
    button2 = "Later",
    OnAccept = function()
        ReloadUI()
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
}

StaticPopupDialogs["LOOTCOLLECTOR_COA_OVERRIDE_WARNING"] = {
	text = "|cffff0000WARNING:|r You are manually setting the realm type to 'CoA'.\n\nThis will permanently DELETE all Mystic Scrolls, Mystic Scroll Vendors, Librams, and Idols from your database.\n\nAre you sure?",
	button1 = "Yes, Proceed",
	button2 = "Cancel",
	OnAccept = function()
		L.db.profile.featureOverrides.realmType = "COA"
		local Constants = L:GetModule("Constants", true)
		if Constants and Constants.DetermineRealmCapabilities then
			Constants:DetermineRealmCapabilities()
			Constants:UpdateAllowedTypes()
		end
		
		local Core = L:GetModule("Core", true)
		if Core and Core.RunUnifiedDatabasePass then
            
			local stats = Core:RunUnifiedDatabasePass()
            local count = (stats and stats.coa) or 0
			print(string.format("|cff00ff00LootCollector:|r Realm mode manually set to COA. Purged %d incompatible entries.", count))
		end
        
		
		StaticPopup_Show("LOOTCOLLECTOR_REALM_OVERRIDE_RELOAD")
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
	showAlert = true,
}

local function buildOptions()
	ensureDefaults()
	local opts = {
		type = "group",
		name = "LootCollector",
		args = {
			visibility = {
				type = "group",
				name = "Visibility",
				inline = false,
				order = 10,
				args = {
pauseAddon = {
						type = "toggle",
						name = "|cffff0000Manual Hibernation (Pause)|r",
						order = 0.1,
						desc = "|cffff0000WARNING:|r Pausing the addon completely stops all background tracking. \n\nYour map icons will vanish, you will not receive network updates, and |cffff7f00any items you loot while paused will NOT be saved to your database.|r",
						get = function() return L.db.char.paused end,
						set = function(_, v) L:TogglePause() end,
					},
					autoPauseInBG = {
						type = "toggle",
						name = "Auto-Hibernate in PvP Instances",
						order = 0.2,
						desc = "Automatically puts the addon into Hibernation Mode while inside Battlegrounds or Arenas to save CPU and network bandwidth.",
						get = function() return L.db.char.autoPauseInBG end,
						set = function(_, v) 
						    L.db.char.autoPauseInBG = v 
						    L:EvaluateAutoPause()
						end,
					},
					autoPauseInRaidInstance = {
						type = "toggle",
						name = "Auto-Hibernate in Raid Instances",
						order = 0.3,
						desc = "Automatically puts the addon into Hibernation Mode while inside Raid instances (e.g. Naxxramas).",
						get = function() return L.db.char.autoPauseInRaidInstance end,
						set = function(_, v) 
						    L.db.char.autoPauseInRaidInstance = v 
						    L:EvaluateAutoPause()
						end,
					},
					autoPauseInRaidGroup = {
						type = "toggle",
						name = "Auto-Hibernate in Raid Groups",
						order = 0.4,
						desc = "Automatically puts the addon into Hibernation Mode whenever you are in a Raid Group, regardless of your location. (Warning: You will miss all open-world discoveries while grouped).",
						get = function() return L.db.char.autoPauseInRaidGroup end,
						set = function(_, v) 
						    L.db.char.autoPauseInRaidGroup = v 
						    L:EvaluateAutoPause()
						end,
					},
					hideAll = {
						type = "toggle",
						name = "Hide All",
						order = 1,
						get = function() return L.db.profile.mapFilters.hideAll end,
						set = function(_, v)
							L.db.profile.mapFilters.hideAll = v
							refreshUI()
						end,
					},
					hideFaded = {
						type = "toggle",
						name = "Hide Faded",
						order = 2,
						get = function() return L.db.profile.mapFilters.hideFaded end,
						set = function(_, v)
							L.db.profile.mapFilters.hideFaded = v
							refreshUI()
						end,
					},
					hideStale = {
						type = "toggle",
						name = "Hide Stale",
						order = 3,
						get = function() return L.db.profile.mapFilters.hideStale end,
						set = function(_, v)
							L.db.profile.mapFilters.hideStale = v
							refreshUI()
						end,
					},
					hideLooted = {
						type = "toggle",
						name = "Hide Looted",
						order = 4,
						desc = "Hide discoveries already looted by this character.",
						get = function() return L.db.profile.mapFilters.hideLooted end,
						set = function(_, v)
							L.db.profile.mapFilters.hideLooted = v
							refreshUI()
						end,
					},
					hideLearnedTransmog = {
						type = "toggle",
						name = "Hide Collected Appearances",
						order = 4.1,
						desc = "Hide discoveries for items with appearances you have already collected.",
						get = function() return L.db.profile.mapFilters.hideLearnedTransmog end,
						set = function(_, v)
							L.db.profile.mapFilters.hideLearnedTransmog = v
							refreshUI()
						end,
					},
					hideCollectedME = {
						type = "toggle",
						name = "Hide Collected Mystic Enchants",
						order = 4.2,
						desc = "Hide Mystic Scroll discoveries for enchants you have already collected.",
						get = function() return L.db.profile.mapFilters.hideCollectedME end,
						set = function(_, v)
							L.db.profile.mapFilters.hideCollectedME = v
							refreshUI()
						end,
					},
					hideBags = {
						type = "toggle",
						name = "Hide Bags",
						order = 4.25,
						desc = "Hide discoveries for bag items (containers). Useful if you already have large bags.",
						get = function() return L.db.profile.mapFilters.hideBags end,
						set = function(_, v)
							L.db.profile.mapFilters.hideBags = v
							refreshUI()
						end,
					},
					disableFadeEffect = {
						type = "toggle",
						name = "Disable Fade Effect",
						order = 4.3,
						desc = "Show all map pins at full opacity, even if their discovery is fading or stale.",
						get = function() return L.db.profile.mapFilters.disableFadeEffect end,
						set = function(_, v)
							L.db.profile.mapFilters.disableFadeEffect = v
							refreshUI()
						end,
					},
                    rarityPinBorders = {
                        type = "toggle",
                        name = "Rarity-colored Pin Borders",
                        order = 4.35,
                        desc = "Off uses a plain item icon (lighter on the map). On adds a quality-colored glow and border.",
                        get = function() return L.db.profile.mapFilters.rarityPinBorders ~= false end,
                        set = function(_, v)
                            L.db.profile.mapFilters.rarityPinBorders = v
                            refreshUI()
                        end,
                    },
					hidePlayerNames = {
						type = "toggle",
						name = "Hide Player Names",
						order = 4.5, 
						desc = "Replaces finder names in toasts and map tooltips with a generic message.",
						get = function()
							return L.db.profile.hidePlayerNames
						end,
						set = function(_, v)
							L.db.profile.hidePlayerNames = v
							refreshUI()
						end,
					},
					hideNonEssential = {
						type = "toggle",
						name = "Hide Non-Essential Messages",
						order = 4.6, 
						desc = "Hides routine maintenance and background caching chat messages.",
						get = function()
							return L.db.profile.hideNonEssential
						end,
						set = function(_, v)
							L.db.profile.hideNonEssential = v
						end,
					},
                    showMinimap = {
                        type = "toggle",
                        name = "Show on Minimap",
                        order = 5,
                        get = function() return L.db.profile.mapFilters.showMinimap end,
                        set = function(_,v) L.db.profile.mapFilters.showMinimap = v; refreshUI() end,
                    },
                    minimapPinSize = {
                        type = "range",
                        name = "Minimap Icon Size",
                        order = 5.01, 
                        min = 6, max = 24, step = 1,
                        disabled = function() return not L.db.profile.mapFilters.showMinimap end,
                        get = function() return L.db.profile.mapFilters.minimapPinSize or 10 end,
                        set = function(_, v)
                            L.db.profile.mapFilters.minimapPinSize = v
                            
                            local Map = L:GetModule("Map", true)
                            if Map and Map.UpdateMinimapPinSizes then
                                Map:UpdateMinimapPinSizes()
                            end
                        end,
                    },
                    maxMinimapDistance = {
                        type = "range",
                        name = "Max Minimap Distance (yards)",
                        order = 5.1,
                        desc = "Only show icons on the minimap if they are within this many yards of you.",
                        min = 100, max = 5000, step = 10,
                        disabled = function() return not L.db.profile.mapFilters.showMinimap end,
                        get = function() return L.db.profile.mapFilters.maxMinimapDistance end,
                        set = function(_, v) L.db.profile.mapFilters.maxMinimapDistance = v; refreshUI() end,
                    },
                    autoTrackNearest = {
                        type = "toggle",
                        name = "Auto-track Nearest Unlooted",
                        order = 5.5,
                        desc = "Automatically enables the arrow to point to the nearest unlooted discovery that matches your filters.",
                        get = function() return L.db.profile.mapFilters.autoTrackNearest end,
                        set = function(_, v)
                            L.db.profile.mapFilters.autoTrackNearest = v
                            local Arrow = L:GetModule("Arrow", true)
                            if Arrow then
                                if v then
                                    Arrow:Show()
                                else
                                    Arrow:Hide()
                                end
                            end
                        end,
                    },
					pinSizeSlider = {
						type = "range",
						name = "Map Icon Size",
						order = 6,
						min = 8,
						max = 32,
						step = 1,
						get = function() return L.db.profile.mapFilters.pinSize end,
						set = function(_, v)
							L.db.profile.mapFilters.pinSize = v
							refreshUI()
						end,
					},
                    showMapFilter = {
                        type = "toggle",
                        name = "Show Map Filter",
                        order = 7,
                        get = function() return L.db.profile.mapFilters.showMapFilter end,
                        set = function(_, v)
                            L.db.profile.mapFilters.showMapFilter = v
                            local Map = L:GetModule("Map", true)
                            if Map and Map.ToggleSearchUI then
                                Map:ToggleSearchUI(v) 
                            end
                        end,
                    },
			  showMinimapButton = {
						type = "toggle",
						name = "Show Minimap Button",
						order = 7.1,
						desc = "Toggle the visibility of the LootCollector minimap button.",
						get = function() return not L.db.profile.minimapButtonHidden end,
						set = function(_, v)
							L.db.profile.minimapButtonHidden = not v
							local MMBtn = L:GetModule("MinimapButton", true)
							if MMBtn then
								if v then 
									MMBtn:Show() 
								else 
									MMBtn:Hide() 
								end
							end
						end,
					},
					disableProximityList = {
						type = "toggle",
						name = "Disable 'Nearby Discoveries'",
						order = 8,
						desc = "Completely disables the 'Nearby Discoveries' list from popping up when hovering over clustered map pins. (You can also hold CTRL to temporarily suppress it).",
						get = function() return L.db.profile.mapFilters.disableProximityList end,
						set = function(_, v)
							L.db.profile.mapFilters.disableProximityList = v
							if v then
								local PL = L:GetModule("ProximityList", true)
								if PL and PL.Hide then PL:Hide() end
							end
						end,
					},										
					toastHeader = {
						type = "header",
						name = "Toast Notifications",
						order = 10,
					},
					toastsEnabled = {
						type = "toggle",
						name = "Show a popup when an item is found",
						order = 11,
						desc = "Uncheck to hide the popup that appears when an item is found. Map pins and sharing stay on. You can also type /lc toasts off.",
						get = function()
							return L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled
						end,
						set = function(_, v)
							if not L.db or not L.db.profile then return end
							L.db.profile.toasts = L.db.profile.toasts or {}
							L.db.profile.toasts.enabled = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
							if not v and Toast and Toast.ClearQueue then
								Toast:ClearQueue()
							end
						end,
					},	
					toastOnlyNew = {
						type = "toggle",
						name = "Only Toast NEW Discoveries",
						order = 11.1,
						desc = "If enabled, only brand new pins will trigger a popup. Updates/Reinforcements to existing pins will be silent.",
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						get = function()
							if L.db.profile.toasts.toastOnlyNew == nil then return true end 
							return L.db.profile.toasts.toastOnlyNew
						end,
						set = function(_, v)
							L.db.profile.toasts.toastOnlyNew = v
						end,
					},
					toastMinQuality = {
						type = "select",
						name = "Minimum Toast Quality",
						order = 11.2,
						desc = "Only show toasts for items of this quality or higher.",
						values = {
							[0] = "|cff9d9d9dPoor|r",
							[1] = "|cffffffffCommon|r",
							[2] = "|cff1eff00Uncommon|r",
							[3] = "|cff0070ddRare|r",
							[4] = "|cffa335eeEpic|r",
							[5] = "|cffff8000Legendary|r"
						},
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						get = function()
							return L.db.profile.toasts.toastMinQuality or 2 
						end,
						set = function(_, v)
							L.db.profile.toasts.toastMinQuality = v
						end,
					},
					toastDisplayTime = {
						type = "range",
						name = "Toast Display Time",
						order = 12,
						min = 2.0,
						max = 10.0,
						step = 0.5,
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						get = function()
							return L.db.profile.toasts.displayTime
						end,
						set = function(_, v)
							L.db.profile.toasts.displayTime = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
						end,
					},
					tickerEnabled = {
						type = "toggle",
						name = "Enable Special Ticker",
						order = 13,
						desc = "Use a scrolling ticker for high-volume discoveries.",
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						get = function()
							return L.db.profile.toasts.tickerEnabled
						end,
						set = function(_, v)
							L.db.profile.toasts.tickerEnabled = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
						end,
					},
					tickerSpeed = {
						type = "range",
						name = "Ticker Scroll Speed",
						order = 14,
						min = 30,
						max = 150,
						step = 5,
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled and L.db.profile.toasts.tickerEnabled)
						end,
						get = function()
							return L.db.profile.toasts.tickerSpeed
						end,
						set = function(_, v)
							L.db.profile.toasts.tickerSpeed = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
						end,
					},
					tickerFontDelta = {
						type = "range",
						name = "Ticker Font Size Adjustment",
						order = 15,
						min = -2,
						max = 8,
						step = 1,
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled and L.db.profile.toasts.tickerEnabled)
						end,
						get = function()
							return L.db.profile.toasts.tickerFontDelta
						end,
						set = function(_, v)
							L.db.profile.toasts.tickerFontDelta = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
						end,
					},
					tickerOutline = {
						type = "toggle",
						name = "Ticker Font Outline",
						order = 16,
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled and L.db.profile.toasts.tickerEnabled)
						end,
						get = function()
							return L.db.profile.toasts.tickerOutline
						end,
						set = function(_, v)
							L.db.profile.toasts.tickerOutline = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplySettings then
								Toast:ApplySettings()
							end
						end,
					},
					whiteFrame = {
						type = "toggle",
						name = "Bright Frame Border",
						order = 17,
						desc = "Use a bright white border for toast frames instead of dim gray.",
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						get = function()
							return L.db.profile.toasts.whiteFrame
						end,
						set = function(_, v)
							L.db.profile.toasts.whiteFrame = v
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ApplyFrameStyle then
								Toast:ApplyFrameStyle()
							end
						end,
					},
					resetToastPosition = {
						type = "execute",
						name = "Reset Toast Position",
						order = 18,
						desc = "Reset toast notifications to default position.",
						disabled = function()
							return not (L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled)
						end,
						func = function()
							local Toast = L:GetModule("Toast", true)
							if Toast and Toast.ResetPosition then
								Toast:ResetPosition()
							end
						end,
					},
				},
			},

			viewerOptions = {
				type = "group",
				name = "Viewer Setup",
				inline = false,
				order = 15,
				args = {
					viewerDesc = {
						type = "description",
						name = "Customize the fonts and spacing for the Discovery Viewer.",
						order = 1,
					},
					rowFont = {
						type = "select",
						name = "List Font (Rows)",
						order = 2,
						values = {
							["Fonts\\ARIALN.TTF"] = "Arial Narrow",
							["Fonts\\FRIZQT__.TTF"] = "Friz Quadrata",
							["Fonts\\2002.TTF"] = "2022",
							["Fonts\\MORPHEUS.ttf"] = "Morpheus",
							["Fonts\\NIM_____.ttf"] = "Nimrod MT"
						},
						get = function() return L.db.profile.viewer.rowFont end,
						set = function(_, v) 
                            L.db.profile.viewer.rowFont = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					rowFontSize = {
						type = "range",
						name = "List Font Size",
						order = 3,
						min = 10, max = 22, step = 1,
						get = function() return L.db.profile.viewer.rowFontSize end,
						set = function(_, v) 
                            L.db.profile.viewer.rowFontSize = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					rowHeight = {
						type = "range",
						name = "Row Height",
						order = 4,
						min = 18, max = 48, step = 1,
						get = function() return L.db.profile.viewer.rowHeight end,
						set = function(_, v) 
                            L.db.profile.viewer.rowHeight = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					uiFont = {
						type = "select",
						name = "UI Font (Headers & Buttons)",
						order = 5,
						values = {
							["Fonts\\ARIALN.TTF"] = "Arial Narrow",
							["Fonts\\FRIZQT__.TTF"] = "Friz Quadrata",
							["Fonts\\2002.TTF"] = "2022",
							["Fonts\\MORPHEUS.ttf"] = "Morpheus",
							["Fonts\\NIM_____.ttf"] = "Nimrod MT"
						},
						get = function() return L.db.profile.viewer.uiFont end,
						set = function(_, v) 
                            L.db.profile.viewer.uiFont = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					uiFontSize = {
						type = "range",
						name = "UI Font Size",
						order = 6,
						min = 10, max = 22, step = 1,
						get = function() return L.db.profile.viewer.uiFontSize end,
						set = function(_, v) 
                            L.db.profile.viewer.uiFontSize = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					useWCAGColoring = {
						type = "toggle",
						name = "Use WCAG Discovery coloring",
						desc = "Adjusts Poor, Rare, and Epic item colors slightly to meet WCAG AA contrast compliance (4.5:1 ratio) on dark backgrounds.",
						order = 7,
						get = function() return L.db.profile.viewer.useWCAGColoring end,
						set = function(_, v) 
                            L.db.profile.viewer.useWCAGColoring = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.ApplySettings then Viewer:ApplySettings() end
                        end,
					},
					useInlineVendorView = {
						type = "toggle",
						name = "Use Inline Vendors Style",
						desc = "Uses expansion style instead of the split view for the Vendors tab.",
						order = 8,
						get = function() return L.db.profile.viewer.inlineVendorView end,
						set = function(_, v) 
                            L.db.profile.viewer.inlineVendorView = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer then 
                                
                                Viewer.expandedVendors = {} 
                                
                                
                                if Viewer.InvalidateFilterCache then
                                    Viewer:InvalidateFilterCache()
                                end
                                
                                if Viewer.ApplySettings then Viewer:ApplySettings() end
                                
                                
                                if Viewer.window and Viewer.window:IsShown() then
                                    Viewer:RefreshData()
                                end
                            end
                        end,
					},
					useInlineVendorView = {
						type = "toggle",
						name = "Use Inline Vendors Style",
						desc = "Reverts the Vendors tab to the old drop-down expansion style instead of the split view.",
						order = 8,
						get = function() return L.db.profile.viewer.inlineVendorView end,
						set = function(_, v) 
                            L.db.profile.viewer.inlineVendorView = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer then 
                                Viewer.expandedVendors = {} 
                                if Viewer.InvalidateFilterCache then Viewer:InvalidateFilterCache() end
                                if Viewer.ApplySettings then Viewer:ApplySettings() end
                                if Viewer.window and Viewer.window:IsShown() then Viewer:RefreshData() end
                            end
                        end,
					},
					
					asyncLoading = {
                        type = "toggle",
                        name = "Delay Viewer Data Loading",
                        desc = function()
                            local baseDesc = "Loads the Discoveries Viewer smoothly in the background over a few seconds to completely eliminate screen freezing, rather than locking the game for a split second."
                            
                            
                            
                            if not L.db.profile.viewer.asyncLoading and L._profilerStats then
                                local stats = L._profilerStats["Viewer:UpdateAllDiscoveries"]
                                if stats and stats.max and stats.max >= 100.0 then
                                    local timeSaved = math.floor(stats.max)
                                    return baseDesc .. string.format("\n\n|cffff7f00If you enable this feature it will eliminate a %dms screen freeze on your machine.|r", timeSaved)
                                end
                            end
                            return baseDesc
                        end,
                        order = 9,
                        get = function() return L.db.profile.viewer.asyncLoading end,
                        set = function(_, v) L.db.profile.viewer.asyncLoading = v end,
                    },

                    animatedBorder = {
                        type = "toggle",
                        name = "Animated Color Border",
                        desc = "Adds a brighter RGB glow, animated border, and matching header accent around the Discoveries viewer.",
                        order = 10,
                        get = function() return L.db.profile.viewer.animatedBorder ~= false end,
                        set = function(_, v)
                            L.db.profile.viewer.animatedBorder = v
                            local Viewer = L:GetModule("Viewer", true)
                            if Viewer and Viewer.RefreshAnimatedBorder then Viewer:RefreshAnimatedBorder() end
                        end,
                    },
				},							
			},
			
			
			sharing = {
				type = "group",
				name = "Behavior & Sharing",
				inline = false,
				order = 20,
				args = {
					autoCache = {
						type = "toggle",
						name = "Automatically Cache Discoveries",
						order = 1,
						desc = "Fetch item info in background for unknown items.",
						get = function()
							return L.db.profile.autoCache
						end,
						set = function(_, v)
							L.db.profile.autoCache = v
							
							
							local queueSize = (L.db and L.db.global and L.db.global.cacheQueue and #L.db.global.cacheQueue) or 0
							
							
							if v then
								if queueSize > 0 then
									print(string.format("|cff00ff00LootCollector|r Automatic item caching is now |cff00ff00ENABLED|r. %d items in queue.", queueSize))
								else
									print("|cff00ff00LootCollector|r Automatic item caching is now |cff00ff00ENABLED|r. Queue is empty.")
								end
							else
								if queueSize > 0 then
									print(string.format("|cffff7f00LootCollector|r Automatic item caching is now |cffff0000DISABLED|r. %d items remain in queue.", queueSize))
								else
									print("|cffff7f00LootCollector|r Automatic item caching is now |cffff0000DISABLED|r.")
								end
							end
							
							
							local Core = L:GetModule("Core", true)
							if Core then
								if v then
									
									if Core.ScanDatabaseForUncachedItems then
										Core:ScanDatabaseForUncachedItems()
									end
									if Core.EnsureCachePump then
										Core:EnsureCachePump()
									end
								else
									
									
									if queueSize > 0 then
										print("|cffffff00LootCollector|r Item cache processing will stop after current item.")
									end
								end
							end
						end,
					},
					sharingHeader = {
						type = "header",
						name = "Sharing Controls",
						order = 9,
					},
					sharingEnabled = {
						type = "toggle",
						name = "Enable Sharing",
						order = 10,
						desc = "Broadcast discoveries to party/raid/guild and the public channel.|n|cFFFFA500Warning: this feature can cause stuttering on some machines even with high FPS.|r",
						get = function()
							return L.db and L.db.profile and L.db.profile.sharing and L.db.profile.sharing.enabled
						end,
						set = function(_, v)
							if not L.db or not L.db.profile then return end
							L.db.profile.sharing = L.db.profile.sharing or {}
							L.db.profile.sharing.enabled = v

							local Comm = L:GetModule("Comm", true)

							if v then
								
								print("|cff00ff00LootCollector:|r Sharing enabled.")
								if Comm then
									if L.channelReady then
										if Comm.EnsureChannelJoined then Comm:EnsureChannelJoined() end
									else
										print("|cffff7f00LootCollector:|r Sharing will be fully enabled after the initial login delay.")
									end
								end
							else
								
								if Comm and Comm.LeavePublicChannel then
									Comm:LeavePublicChannel()
								end

								local clearedBroadcasts = 0
								local Core = L:GetModule("Core", true)
								if Core and Core.pendingBroadcasts then
									for _ in pairs(Core.pendingBroadcasts) do clearedBroadcasts = clearedBroadcasts + 1 end
									wipe(Core.pendingBroadcasts)
								end

								if Comm and Comm._rateLimitQueue then
									clearedBroadcasts = clearedBroadcasts + #Comm._rateLimitQueue
									wipe(Comm._rateLimitQueue)
								end

								local clearedToasts = 0
								local Toast = L:GetModule("Toast", true)
								if Toast and Toast.ClearQueue then
									clearedToasts = Toast:ClearQueue()
								end

								print(string.format("|cffff7f00LootCollector:|r Sharing disabled. Cleared %d pending broadcasts and %d pending notifications.", clearedBroadcasts, clearedToasts))
							end
						end,
					},					
					namelessSharing = {
						type = "toggle",
						name = "Nameless Sharing",
						order = 11,
						desc = "Share discoveries anonymously.",
						disabled = function()
							return not L.db.profile.sharing.enabled
						end,
						get = function()
							return L.db and L.db.profile and L.db.profile.sharing and L.db.profile.sharing.anonymous
						end,
						set = function(_, v)
							if not L.db or not L.db.profile then return end
							L.db.profile.sharing = L.db.profile.sharing or {}
							L.db.profile.sharing.anonymous = (not not v)
						end,
					},
					delayedSharing = {
						type = "toggle",
						name = "Delayed Sharing",
						order = 12,
						desc = "Delay outgoing shares by a set number of seconds.",
						disabled = function()
							return not L.db.profile.sharing.enabled
						end,
						get = function()
							return L.db.profile.sharing.delayed
						end,
						set = function(_, v)
							L.db.profile.sharing.delayed = v
						end,
					},
					delaySlider = {
						type = "range",
						name = "Sharing Delay",
						order = 13,
						min = 15,
						max = 60,
						step = 1,
						disabled = function()
							return not L.db.profile.sharing.enabled or not L.db.profile.sharing.delayed
						end,
						get = function()
							return L.db.profile.sharing.delaySeconds
						end,
						set = function(_, v)
							L.db.profile.sharing.delaySeconds = v
						end,
					},
                    allowShowRequests = {
                        type = "toggle",
                        name = "Allow 'Show' Requests",
                        order = 14,
                        desc = "Allow other players to send you discovery locations to view on your map.",
                        disabled = function() return not L.db.profile.sharing.enabled end,
                        get = function() return L.db.profile.sharing.allowShowRequests end,
                        set = function(_, v) L.db.profile.sharing.allowShowRequests = v end,
                    },
			   
					  dataTypesHeader = {
								type = "header",
								name = "Data Types",
								order = 14.1,
							},
					disableMysticScrolls = {
								type = "toggle",
								name = "Disable Mystic Scrolls",
								desc = "If checked, Mystic Scroll discoveries will not be recorded, shared, or received from others.",
								order = 14.2,
								hidden = function() 
								    local Constants = L:GetModule("Constants", true)
								    return Constants and not Constants:HasMysticScrolls()
								end,
						get = function() return L.db.profile.disableMysticScrolls end,
						set = function(_, v) 
						    L.db.profile.disableMysticScrolls = v 
						    
						    local Constants = L:GetModule("Constants", true)
						    if Constants and Constants.UpdateAllowedTypes then
							  Constants:UpdateAllowedTypes()
						    end
						end,
					  },
					syncHeader = {
						type = "header",
						name = "Sync Restrictions",
						order = 19,
					},
					rejectPartySync = {
						type = "toggle",
						name = "Block Party/Raid Sync",
						order = 20,
						get = function()
							return L.db.profile.sharing.rejectPartySync
						end,
						set = function(_, v)
							L.db.profile.sharing.rejectPartySync = v
						end,
					},
					rejectGuildSync = {
						type = "toggle",
						name = "Block Guild Sync",
						order = 21,
						get = function()
							return L.db.profile.sharing.rejectGuildSync
						end,
						set = function(_, v)
							L.db.profile.sharing.rejectGuildSync = v
						end,
					},
					rejectWhisperSync = {
						type = "toggle",
						name = "Block Whisper Sync",
						order = 22,
						get = function()
							return L.db.profile.sharing.rejectWhisperSync
						end,
						set = function(_, v)
							L.db.profile.sharing.rejectWhisperSync = v
						end,
					},
					playerListsHeader = {
						type = "header",
						name = "Player Lists",
						order = 29,
					},
					blockList = {
						type = "input",
						multiline = 5,
						width = "full",
						order = 30,
						name = "Blocked Players",
						desc = "One player per line. Blocks messages sent from these players or discoveries originally found by them.",
						get = function()
							return listToString(L.db.profile.sharing.blockList)
						end,
						set = function(_, v)
							stringToList(v, L.db.profile.sharing.blockList)
						end,
					},
                    purgeGroup = {
                        type = "group",
                        name = "",
                        order = 30.1,
                        inline = true,
                        args = {
                            spacer = {
                                type = "description",
                                name = "",
                                width = "full",
                                order = 1,
                            },
                            purgeBlockedData = {
                                type = "execute",
                                name = "Purge Blocked Players Data",
                                desc = "Removes all discoveries from your database where the original finder ('fp') is on your block list.",
                                order = 2,
                                func = function()
                                    local Core = L:GetModule("Core", true)
                                    if Core and Core.PurgeDiscoveriesFromBlockedPlayers then
                                        Core:PurgeDiscoveriesFromBlockedPlayers()
                                    else
                                        print("|cffff7f00LootCollector:|r Core module not available to perform purge.")
                                    end
                                end,
                            },
                        },
                    },
					whiteList = {
						type = "input",
						multiline = 5,
						width = "full",
						order = 31,
						name = "Whitelisted Players",
						desc = "If non-empty, only these players are accepted.",
						get = function()
							return listToString(L.db.profile.sharing.whiteList)
						end,
						set = function(_, v)
							stringToList(v, L.db.profile.sharing.whiteList)
						end,
					},
				},
			},
			
			realmOverridesHeader = {
						type = "header",
						name = "Realm Capability Overrides",
						order = 40,
					},
                    overrideDesc = {
                        type = "description",
                        name = "LootCollector automatically detects the realm type (Ascension / Grimfall) to optimize UI and features. If detection fails, you can force the mode here.\n|cffff0000Requires a /reload to apply changes.|r",
                        order = 41,
                    },
			realmTypeOverride = {
						type = "select",
						name = "Active Realm Mode",
						order = 42,
						width = 1.6,
						values = {
                            ["AUTO"] = "Auto-Detect (Recommended)",
                            ["WR"] = "Warcraft Reborn (Bronzebeard) + Mystic Scrolls",
                            ["WILDCARD"] = "Wildcard (Area 52)",
                            ["COA"] = "CoA / Grimfall (Sargeras, Vol'jin) - Worldforged, No Scrolls",
                            ["CLASSLESS"] = "Classless (Whisperwind / Elune) - No Scrolls",
                        },
						get = function() return L.db.profile.featureOverrides.realmType end,
						set = function(_, v) 
						    if v == "COA" then
						        StaticPopup_Show("LOOTCOLLECTOR_COA_OVERRIDE_WARNING")
						    else
                                L.db.profile.featureOverrides.realmType = v
                                local Constants = L:GetModule("Constants", true)
                                if Constants and Constants.DetermineRealmCapabilities then
                                    Constants:DetermineRealmCapabilities()
                                    Constants:UpdateAllowedTypes()
                                end
                                print("|cff00ff00LootCollector:|r Realm mode manually set to " .. v .. ".")
                                
                                StaticPopup_Show("LOOTCOLLECTOR_REALM_OVERRIDE_RELOAD")
						    end
						end,
					},
            about = {
                type = "group",
                name = "About",
                order = 99,
                args = {
                    title = {
                        type = "description",
                        name = "|cff00ff96LootCollector|r",
                        fontSize = "large",
                        order = 1,
                    },
                    desc = {
                        type = "description",
                        name = "LootCollector for CoA. Worldforged pins are shared with other people running this addon. Looting a Worldforged item moves that pin to where you were standing and sends the new spot.",
                        fontSize = "medium",
                        order = 2,
                    },
                    version = {
                        type = "description",
                        name = "Version 1.1.0  |  2026-11-01",
                        fontSize = "medium",
                        order = 3,
                    },
                }
            },
		},
	}
	return opts
end

local function SetSharingEnabled(enabled)
	if not (L.db and L.db.profile) then return end
	L.db.profile.sharing = L.db.profile.sharing or {}
	L.db.profile.sharing.enabled = not not enabled

	local Comm = L:GetModule("Comm", true)
	if enabled then
		print("|cff00ff00LootCollector:|r Sharing enabled.")
		if Comm then
			if L.channelReady then
				if Comm.EnsureChannelJoined then
					Comm:EnsureChannelJoined()
				elseif Comm.JoinPublicChannel then
					Comm:JoinPublicChannel(true)
				end
			else
				print("|cffff7f00LootCollector:|r Sharing will be fully enabled after the initial login delay.")
			end
		end
	else
		if Comm and Comm.LeavePublicChannel then
			Comm:LeavePublicChannel()
		end

		local clearedBroadcasts = 0
		local Core = L:GetModule("Core", true)
		if Core and Core.pendingBroadcasts then
			for _ in pairs(Core.pendingBroadcasts) do clearedBroadcasts = clearedBroadcasts + 1 end
			wipe(Core.pendingBroadcasts)
		end
		if Comm and Comm._rateLimitQueue then
			clearedBroadcasts = clearedBroadcasts + #Comm._rateLimitQueue
			wipe(Comm._rateLimitQueue)
		end
		local clearedToasts = 0
		local Toast = L:GetModule("Toast", true)
		if Toast and Toast.ClearQueue then
			clearedToasts = Toast:ClearQueue()
		end
		print(string.format("|cffff7f00LootCollector:|r Sharing disabled. Cleared %d pending broadcasts and %d pending notifications.", clearedBroadcasts, clearedToasts))
	end
end

-- AceConfig/AceGUI are NOT bundled with this addon. When another addon provides
-- them, embedding AceConfigDialog into Interface Options builds a huge widget
-- tree and tanks FPS on weak hardware. Keep Blizzard options native/lightweight.
local function CreateNativeOptionsPanel()
	local panel = CreateFrame("Frame", "LootCollectorBlizOptionsPanel", InterfaceOptionsFramePanelContainer)
	panel.name = "LootCollector"

	local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("LootCollector")

	local note = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	note:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
	note:SetWidth(520)
	note:SetJustifyH("LEFT")
	note:SetText("Lightweight settings panel (avoids AceConfig lag). Chat: |cff00ff00/lc sharing on|r or |cff00ff00/lc sharing off|r")

	local y = -70
	local function AddCheck(name, label, tooltip, getter, setter)
		local cb = CreateFrame("CheckButton", name, panel, "InterfaceOptionsCheckButtonTemplate")
		cb:SetPoint("TOPLEFT", 16, y)
		_G[cb:GetName() .. "Text"]:SetText(label)
		cb.tooltipText = label
		cb.tooltipRequirement = tooltip
		cb:SetScript("OnShow", function(self)
			self:SetChecked(getter() and true or false)
		end)
		cb:SetScript("OnClick", function(self)
			setter(self:GetChecked() and true or false)
			self:SetChecked(getter() and true or false)
		end)
		y = y - 28
		return cb
	end

	AddCheck("LootCollectorOpt_Sharing", "Enable Sharing",
		"Broadcast and receive discoveries on the public LootCollector channel. Can stutter; channel chat also needs level 2+ on some realms.",
		function()
			return L.db and L.db.profile and L.db.profile.sharing and L.db.profile.sharing.enabled
		end,
		function(v) SetSharingEnabled(v) end)

	AddCheck("LootCollectorOpt_Anonymous", "Nameless Sharing",
		"Share discoveries without attaching your character name.",
		function()
			return L.db and L.db.profile and L.db.profile.sharing and L.db.profile.sharing.anonymous
		end,
		function(v)
			L.db.profile.sharing = L.db.profile.sharing or {}
			L.db.profile.sharing.anonymous = not not v
		end)

	AddCheck("LootCollectorOpt_AutoCache", "Automatically Cache Discoveries",
		"Fetch item names/icons in the background for unknown discoveries.",
		function() return L.db and L.db.profile and L.db.profile.autoCache end,
		function(v)
			L.db.profile.autoCache = not not v
			local Core = L:GetModule("Core", true)
			if Core then
				if v then
					if Core.ScanDatabaseForUncachedItems then Core:ScanDatabaseForUncachedItems() end
					if Core.EnsureCachePump then Core:EnsureCachePump() end
				end
			end
		end)

	AddCheck("LootCollectorOpt_HideWorldMap", "Hide World Map Pins",
		"Hide LootCollector pins on the world map only.",
		function()
			local f = L.db and L.db.profile and L.db.profile.mapFilters
			return f and (f.hideWorldMap or f.hideAll) and true or false
		end,
		function(v)
			L.db.profile.mapFilters.hideWorldMap = not not v
			if not v then L.db.profile.mapFilters.hideAll = false end
			refreshUI()
		end)

	AddCheck("LootCollectorOpt_HideMinimap", "Hide Minimap Pins",
		"Hide LootCollector pins on the minimap only.",
		function()
			local f = L.db and L.db.profile and L.db.profile.mapFilters
			return f and (f.hideMinimap or f.hideAll or f.showMinimap == false) and true or false
		end,
		function(v)
			L.db.profile.mapFilters.hideMinimap = not not v
			L.db.profile.mapFilters.showMinimap = not v
			if not v then L.db.profile.mapFilters.hideAll = false end
			refreshUI()
		end)

	AddCheck("LootCollectorOpt_HideLooted", "Hide Looted",
		"Hide discoveries already unlocked (per the scope below).",
		function() return L.db and L.db.profile and L.db.profile.mapFilters and L.db.profile.mapFilters.hideLooted end,
		function(v)
			L.db.profile.mapFilters.hideLooted = not not v
			refreshUI()
		end)

	AddCheck("LootCollectorOpt_LootedAccount", "Account-wide looted status",
		"ON: gray pins if ANY character on this account unlocked the item (tooltip lists who). OFF: only this character counts.",
		function()
			return not (L.db and L.db.profile and L.db.profile.lootedScope == "character")
		end,
		function(v)
			L.db.profile.lootedScope = v and "account" or "character"
			refreshUI()
		end)

	AddCheck("LootCollectorOpt_Toasts", "Show a popup when an item is found",
		"Uncheck to hide the popup that appears when an item is found. Map pins and sharing stay on.",
		function() return L.db and L.db.profile and L.db.profile.toasts and L.db.profile.toasts.enabled end,
		function(v)
			L.db.profile.toasts = L.db.profile.toasts or {}
			L.db.profile.toasts.enabled = not not v
			if not v then
				local Toast = L:GetModule("Toast", true)
				if Toast and Toast.ClearQueue then Toast:ClearQueue() end
			end
		end)

	AddCheck("LootCollectorOpt_Pause", "|cffff0000Manual Hibernation (Pause)|r",
		"Stops tracking, map icons, and network updates. Items looted while paused are not saved.",
		function() return L.db and L.db.char and L.db.char.paused end,
		function()
			if L.TogglePause then L:TogglePause() end
		end)

	local hint = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	hint:SetPoint("TOPLEFT", 16, y - 12)
	hint:SetWidth(520)
	hint:SetJustifyH("LEFT")
	hint:SetText("More categories: Discoveries (import/lists). Advanced AceConfig UI: |cff00ff00/lc advanced|r (only if another addon provides Ace3 Config).")

	InterfaceOptions_AddCategory(panel)
	return panel
end

function Settings:OnInitialize()
	
	
	local function showLegacyMessage()
		print("|cffff0000LootCollector is in Legacy Mode!|r")
		print("|cffffff00Your database is from an older version and needs to be updated.|r")
		print("  - Type |cff00ff00/lcpreserve|r to migrate your data now.")
		print("  - Type |cffff7f00/reload|r to see the migration pop-up again.")
	end

	if L.LEGACY_MODE_ACTIVE then
		
		self:RegisterChatCommand("lc", showLegacyMessage)
		self:RegisterChatCommand("lootcollector", showLegacyMessage)
		SLASH_LCLIST1 = "/lclist"
		SlashCmdList["LCLIST"] = showLegacyMessage
		return 
	end

	
	if not (L.db and L.db.profile) then return end
	ensureDefaults()

	CreateNativeOptionsPanel()

	-- Optional floating advanced UI only. Never embed AceConfig into Interface Options.
	if AceConfig and AceConfigDialog then
		local optionsTable = buildOptions()
		AceConfig:RegisterOptionsTable("LootCollector", optionsTable)
	end

	local function handleLcCommand(input)
		input = input or ""
		local cmd, val = input:match("^%s*(%S+)%s*(%S*)")
		cmd = cmd and cmd:lower() or ""
		val = val and val:lower() or ""

		if cmd == "sharing" then
			local on = not (val == "0" or val == "off" or val == "false")
			if val == "" then
				local cur = L.db.profile.sharing and L.db.profile.sharing.enabled
				print(string.format("|cff00ff00LootCollector|r sharing is currently %s. Use |cff00ff00/lc sharing on|r or |cff00ff00/lc sharing off|r", cur and "ON" or "OFF"))
				return
			end
			SetSharingEnabled(on)
			return
		elseif cmd == "advanced" or cmd == "config" then
			if AceConfig and AceConfigDialog then
				AceConfigDialog:Open("LootCollector")
			else
				print("|cffff7f00LootCollector|r Advanced AceConfig UI is unavailable (AceConfig not loaded by any addon). Use Interface > AddOns > LootCollector.")
			end
			return
		elseif cmd == "toasts" or cmd == "hideall" or cmd == "hidefaded" or cmd == "hidestale" or cmd == "hidelooted" then
			local on = not (val == "0" or val == "off" or val == "false")
			if cmd == "toasts" then
				L.db.profile.toasts = L.db.profile.toasts or {}
				L.db.profile.toasts.enabled = on
				print(string.format("|cff00ff00LootCollector|r item-found popups are %s.", on and "ON" or "OFF"))
				if not on then
					local Toast = L:GetModule("Toast", true)
					if Toast and Toast.ClearQueue then Toast:ClearQueue() end
				end
			else
				L.db.profile.mapFilters[cmd] = on
				print(string.format("|cff00ff00LootCollector|r mapFilters.%s=%s", cmd, tostring(on)))
				refreshUI()
			end
			return
		elseif cmd == "discoveries" then
			InterfaceOptionsFrame_OpenToCategory("LootCollector")
			InterfaceOptionsFrame_OpenToCategory("Discoveries")
			return
		elseif cmd == "help" then
			print("|cff00ff00LootCollector|r /lc sharing on|off, /lc advanced, /lc discoveries, /lc toasts on/off (item-found popups), /lc hideall on/off, /lc hidelooted on/off")
			return
		end

		InterfaceOptionsFrame_OpenToCategory("LootCollector")
		InterfaceOptionsFrame_OpenToCategory("LootCollector")
	end

	self:RegisterChatCommand("lc", handleLcCommand)
	self:RegisterChatCommand("lootcollector", handleLcCommand)

	SLASH_LootCollectorTOP1 = "/lctop"
	SlashCmdList["LootCollectorTOP"] = ShowTopContributors
end

return Settings

local L = LootCollector
local Detect = L:NewModule("Detect", "AceEvent-3.0")

local LEGACY_DETECT_MODE = false 

Detect.recentlyScannedNPCs = Detect.recentlyScannedNPCs or {} 
Detect._cache, Detect._recent = { isWF = {}, isMS = {} }, {}
Detect._dirtyBags = {}
Detect._bagUpdateTimer = nil

Detect._lastDiscoveryGUID = nil
Detect._lastDiscoveryTime = 0
Detect._recoverySuppressionUntil = 0
local RECOVERY_SUPPRESSION_WINDOW = 9.0

local NPCScanTip = CreateFrame("GameTooltip", "LootCollector_NPCScanTip", UIParent, "GameTooltipTemplate")
NPCScanTip:SetOwner(UIParent, "ANCHOR_NONE")

local lastLootContext = {
    openedAt = 0,
    mapID = 0,
    c = 0, z = 0, iz = 0,
    x = 0, y = 0,
}
Detect._ctx = {
  lastLootOpenedAt = nil,
  lastGossipAt = nil,
  lastMerchantAt = nil,
  lastEmoteAt = nil,
  lastMailTakeAt = nil,
  mailOpen = false,
  mailClosedAt = nil,
  lastQuestCompleteAt = nil,
  lastQuestFinishedAt = nil, 
  lastQuestTurnedInAt = nil, 
  lastQuestMsgAt = nil,      
  lastTradeAcceptedAt = nil,
  tradeOpen = false,
  tradeClosedAt = nil,
  craftingOpen = false,
  
  bankOpen = false,
  bankClosedAt = nil,
  guildBankOpen = false,
  guildBankClosedAt = nil,
  lastAchievementAt = nil,
  lastBuybackAt = nil,
}
local LOOT_VALIDITY_WINDOW = 20
local CONTAINER_LINGER = 6.0
local ITEM_EXPECTATION_WINDOW = 9.0 

Detect._expectingItemUntil = 0
Detect._expectedItemLink = nil
-- itemID -> chat/loot link seen in the current LOOT_OPENED window
Detect._openLootItems = {}

function Detect:Debug(msg, ...) return end

local function ParseItemID(link)
  if not link then return nil end
  return tonumber(link:match("item:(%d+)"))
end

local SCAN_TIP_NAME = "LootCollectorDetectScanTip"
local scanTip = nil

local function EnsureScanTip()
    if scanTip then return end
    scanTip = CreateFrame("GameTooltip", SCAN_TIP_NAME, nil, "GameTooltipTemplate")
    scanTip:SetOwner(UIParent, "ANCHOR_NONE")
end

local WF_NEEDLES = {
    "worldforged",
    "world-forged",
    "world forged",
    "worldforged item",
}

local function TooltipHasAny(link, needles)
    local pTime = L.ProfileStart and L:ProfileStart() 

    if not link or not needles then 
        if pTime then L:ProfileStop("Scanner:TooltipHas", pTime) end
        return false 
    end
    EnsureScanTip()
    scanTip:SetOwner(UIParent, "ANCHOR_NONE")
    scanTip:ClearLines()
    scanTip:SetHyperlink(link)

    local line1Left = _G[SCAN_TIP_NAME .. "TextLeft1"]
    local line1 = line1Left and line1Left:GetText()
    if line1 == "Retrieving item information..." then
        if pTime then L:ProfileStop("Scanner:TooltipHas", pTime) end
        return nil
    end

    local numLines = (scanTip.NumLines and scanTip:NumLines()) or 30
    for i = 1, numLines do
        local fs = _G[SCAN_TIP_NAME .. "TextLeft" .. i]
        local text = fs and fs:GetText()
        if text then
            local lower = string.lower(text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
            for _, needle in ipairs(needles) do
                if string.find(lower, needle, 1, true) then
                    if pTime then L:ProfileStop("Scanner:TooltipHas", pTime) end
                    return true
                end
            end
        end
    end
    
    if pTime then L:ProfileStop("Scanner:TooltipHas", pTime) end
    return false
end

local function TooltipHas(link, needle)
    return TooltipHasAny(link, { string.lower(needle or "") })
end

local function ScanMerchant()
  local items = {}
  local n = GetMerchantNumItems()
  if n == 0 then return items end
  
  for i = 1, n do
    local link = GetMerchantItemLink(i)
    local name, texture, price, quantity, numAvailable, isUsable, extendedCost = GetMerchantItemInfo(i)
    local itemID = ParseItemID(link)

    local costs = {}
    if extendedCost then
      local costKinds = GetMerchantItemCostInfo(i)
      for j = 1, (costKinds or 0) do
        local costTexture, costAmount, costLink, currencyName = GetMerchantItemCostItem(i, j)
        local costItemID = ParseItemID(costLink)
        costs[#costs+1] = {
          amount = costAmount,
          link = costLink,
          itemID = costItemID,
          currencyName = currencyName,
          texture = costTexture,
        }
      end
    end

    if itemID then
        items[#items+1] = {
          index = i,
          itemID = itemID,
          link = link,
          name = name,
          price = price,
          stack = quantity,
          numAvailable = numAvailable,
          isUsable = isUsable,
          extendedCost = extendedCost,
          costs = costs,
        }
    end
  end
  return items
end

local function GetNPCSubname(unit)
  if not unit or not UnitExists(unit) then return nil end
  NPCScanTip:ClearLines()
  NPCScanTip:SetUnit(unit)
  local line2 = _G["LootCollector_NPCScanTipTextLeft2"]
  local text = line2 and line2:IsShown() and line2:GetText() or nil

  if text then
      
      local cleanText = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
      if cleanText:match("^Level %d") or tonumber(cleanText:match("(%d+)")) then
          return nil
      end
  end
  return text
end

function Detect:IsWorldforged(link)
    local c = self._cache.isWF[link]
    if c ~= nil then return c end

    local ok = TooltipHasAny(link, WF_NEEDLES)
    
    if ok == nil then
        L._ddebug("Detect", string.format("IsWorldforged scan for %s: Retrieving item data (nil from TooltipHas)", tostring(link)))
        return nil 
    end

    L._ddebug("Detect", string.format("IsWorldforged scan for %s: %s", tostring(link), tostring(ok)))
    -- Only cache definitive true. A false may be a not-yet-fully-loaded tip
    -- on some clients; leave uncached so a later loot/bag pass can retry.
    if ok then
        self._cache.isWF[link] = true
    end
    return ok
end

function Detect:IsMysticScroll(link, source)
  local Constants = L:GetModule("Constants", true)
  if Constants and not Constants:HasMysticScrolls() then return false end

  local name = (link and select(1, GetItemInfo(link))) or (link and link:match("%[(.-)%]")) or ""
  if name == "" then return false end
  if L.ignoreList and L.ignoreList[name] then return false end
  if L.sourceSpecificIgnoreList and L.sourceSpecificIgnoreList[name] and source ~= "world_loot" and source ~= "direct" then
    return false
  end
  return string.find(name, "Mystic Scroll:", 1, true) ~= nil
end

function Detect:Qualifies(link, source)
  if not link then return false end
  local isWF = self:IsWorldforged(link)
  local isMS = self:IsMysticScroll(link, source)
  
  
  if isWF == nil then
      L._ddebug("Detect", string.format("Qualifies check for %s | WF: Data Not Ready, MS: %s", tostring(link), tostring(isMS)))
      return nil
  end
  
  L._ddebug("Detect", string.format("Qualifies check for %s | WF: %s, MS: %s", tostring(link), tostring(isWF), tostring(isMS)))
  return isWF or isMS
end

function Detect:OnRetroactiveSuppressionEvent(event, arg1, arg2)
    local shouldSuppress = false
    local reason = "Unknown"

    if event == "UI_INFO_MESSAGE" and arg1 == "|cFF2EF50EItem recovery completed|r" then
        shouldSuppress = true
        reason = "item recovery"
    elseif event == "RECOVERY_RESULT" and arg2 and type(arg2) == "string" and string.find(arg2, "_OK$") then
        shouldSuppress = true
        reason = "item recovery"
    elseif event == "PURCHASE_CUSTOM_STORE_ITEM_RESULT" and arg1 == "PURCHASE_CUSTOM_STORE_ITEM_OK" then
        
        shouldSuppress = true
        reason = "store purchase or upgrade"
    end

    if shouldSuppress then
        L._ddebug("Detect", "Retroactive suppression event detected: " .. event)
        local now = GetTime()
        
        
        if self._lastDiscoveryGUID and (now - self._lastDiscoveryTime < 2.5) then
            local Core = L:GetModule("Core", true)
            if Core and Core.RemoveDiscoveryByGuid then
                L._ddebug("Detect", "Retroactively removing false discovery due to " .. reason .. ": " .. self._lastDiscoveryGUID)
                Core:RemoveDiscoveryByGuid(self._lastDiscoveryGUID, "Discovery suppressed due to " .. reason .. ".")
            end
        end

        
        self._lastDiscoveryGUID = nil
        self._lastDiscoveryTime = 0
    end
end

local function IsBlackmarketArtisan(unit)
  local sub = GetNPCSubname(unit)
  return sub and sub:find("Blackmarket Artisan Supplies", 1, true) ~= nil
end

function Detect:OnNPCInteraction()
if L:IsPaused() then return end
    local unitToCheck = "npc"
    if not UnitExists(unitToCheck) then return end

    local npcGUID = UnitGUID(unitToCheck)
    if not npcGUID then return end

    
    if self.recentlyScannedNPCs[npcGUID] and (time() - self.recentlyScannedNPCs[npcGUID] < 10) then
        return
    end
    -- Arm the throttle for EVERY vendor, not just MS/BM ones: MERCHANT_UPDATE
    -- refires repeatedly while the window is open, and without this the scan
    -- below reruns on each event for ordinary vendors (client-freezing loop).
    self.recentlyScannedNPCs[npcGUID] = time()

    local isBMVendor = IsBlackmarketArtisan(unitToCheck)
    local isMSVendor = false

    local merchantItems = {}
    if GetMerchantNumItems() > 0 then
        merchantItems = ScanMerchant()
    end

    local Constants = L:GetModule("Constants", true)
    if not isBMVendor and Constants and Constants:HasMysticScrolls() then
        for _, itemData in ipairs(merchantItems) do
            if itemData.name and string.find(itemData.name, "Mystic Scroll", 1, true) then
                isMSVendor = true
                break
            end
        end
    end

    if not isMSVendor and not isBMVendor then return end

    local vendorType = isMSVendor and "MS" or "BM"
    local now = time()
    
    local px, py = GetPlayerMapPosition("player")
    px = px or 0; py = py or 0

    SetMapToCurrentZone()
    local mapID = GetCurrentMapAreaID()
    local ZoneList = L:GetModule("ZoneList", true)
    local zoneInfo = ZoneList and ZoneList.MapDataByID[mapID]

    local c, z, iz
    if zoneInfo then
        c = zoneInfo.continentID
        z = mapID
        iz = 0
    else 
        c = GetCurrentMapContinent() or 0
        z = mapID
        iz = mapID
    end

    local discovery = {
        c = c, z = z, iz = iz, mapID = mapID,
        xy = { x = px, y = py }, 
        t0 = now,
        src = "merchant",
        vendorType = vendorType, 
        vendorName = UnitName(unitToCheck),
        vendorItems = merchantItems, 
        fp = UnitName("player"),
        dt = Constants and Constants.DISCOVERY_TYPE.BLACKMARKET,
    }

    local Core = L:GetModule("Core", true)
    if Core and Core.HandleLocalLoot then
        L._ddebug("Detect", string.format("Passing Vendor %s (%s) to Core.", discovery.vendorName, vendorType))
        Core:HandleLocalLoot(discovery)
    end
end

local function CaptureLootWindowItems()
    wipe(Detect._openLootItems)
    local n = GetNumLootItems and GetNumLootItems() or 0
    for i = 1, n do
        local link = GetLootSlotLink and GetLootSlotLink(i)
        if link then
            local id = tonumber(link:match("item:(%-?%d+)"))
            if id then
                Detect._openLootItems[id] = link
            end
        end
    end
end

local function HasFreshWorldLootContext()
    local now = time()
    if not lastLootContext.openedAt or (now - lastLootContext.openedAt) > LOOT_VALIDITY_WINDOW then
        return false
    end
    if not lastLootContext.z or lastLootContext.z == 0 then
        return false
    end
    -- 0,0 is almost never a real outdoor loot spot; reject so we don't
    -- stamp pins at the origin / capital fallback.
    if (tonumber(lastLootContext.x) or 0) == 0 and (tonumber(lastLootContext.y) or 0) == 0 then
        return false
    end
    return true
end

local function EnsurePendingTicker()
    if Detect._pendingBagLootTicker then return end
    if not Detect._pendingBagLoot or not next(Detect._pendingBagLoot) then return end
    Detect._pendingBagLootTicker = true
    local function tickPending()
        if not Detect._pendingBagLoot or not next(Detect._pendingBagLoot) then
            Detect._pendingBagLootTicker = nil
            return
        end
        Detect:ResolvePendingBagLoot()
        if Detect._pendingBagLoot and next(Detect._pendingBagLoot) then
            L:ScheduleAfter(0.35, tickPending)
        else
            Detect._pendingBagLootTicker = nil
        end
    end
    L:ScheduleAfter(0.25, tickPending)
end

local function ArmPendingFromLootWindow()
    if not HasFreshWorldLootContext() then return end
    if not Detect._openLootItems or not next(Detect._openLootItems) then return end

    Detect._pendingBagLoot = Detect._pendingBagLoot or {}
    local looter = UnitName("player")
    for itemID, link in pairs(Detect._openLootItems) do
        if not Detect._pendingBagLoot[itemID] and not Detect._recent["id:" .. itemID] then
            Detect._pendingBagLoot[itemID] = {
                chatLink = link,
                src = "world_loot",
                c = lastLootContext.c,
                z = lastLootContext.z,
                iz = lastLootContext.iz,
                x = lastLootContext.x,
                y = lastLootContext.y,
                fp = looter,
                t0 = lastLootContext.openedAt,
                tries = 0,
                fromLootWindow = true,
            }
        end
    end

    EnsurePendingTicker()
end

local function RefreshLootContextPosition()
    if SetMapToCurrentZone then SetMapToCurrentZone() end
    local mapID = GetCurrentMapAreaID()
    lastLootContext.mapID = mapID

    local ZoneList = L:GetModule("ZoneList", true)
    local zoneInfo = ZoneList and ZoneList.MapDataByID[mapID]
    if zoneInfo then
        lastLootContext.c = zoneInfo.continentID
        lastLootContext.z = mapID
        lastLootContext.iz = 0
    else
        lastLootContext.c = GetCurrentMapContinent() or 0
        lastLootContext.z = mapID
        lastLootContext.iz = mapID
    end

    local px, py = GetPlayerMapPosition("player")
    lastLootContext.x = px or 0
    lastLootContext.y = py or 0

    -- Prefer Map module cache when the raw API returns 0,0 (common while the
    -- world map is open to another zone).
    if (lastLootContext.x == 0 and lastLootContext.y == 0) then
        local Map = L:GetModule("Map", true)
        if Map and Map.GetPlayerLocation then
            local _, mmapID, mpx, mpy = Map:GetPlayerLocation(true)
            if mpx and mpy and (mpx > 0 or mpy > 0) then
                lastLootContext.x, lastLootContext.y = mpx, mpy
                if mmapID and mmapID > 0 then
                    lastLootContext.mapID = mmapID
                    lastLootContext.z = mmapID
                end
            end
        end
    end
end

function Detect:OnLootOpened()
    self._ctx.lastLootOpenedAt = time()
    lastLootContext.openedAt = time()
    RefreshLootContextPosition()
    CaptureLootWindowItems()

    -- One retry: some clients report 0,0 on the first loot tick.
    if (lastLootContext.x == 0 and lastLootContext.y == 0) then
        L:ScheduleAfter(0.15, function()
            if lastLootContext.openedAt and (time() - lastLootContext.openedAt) <= LOOT_VALIDITY_WINDOW then
                RefreshLootContextPosition()
                CaptureLootWindowItems()
            end
        end)
    end
end

function Detect:OnLootClosed()
    self._expectingItemUntil = GetTime() + ITEM_EXPECTATION_WINDOW
    -- If OPENED still had 0,0, try once more before arming pendings.
    if (lastLootContext.x == 0 and lastLootContext.y == 0) then
        RefreshLootContextPosition()
    end
    CaptureLootWindowItems()
    ArmPendingFromLootWindow()
    if self.OnBagUpdate then
        self:OnBagUpdate("LOOT_CLOSED", nil)
    end
end

function Detect:OnSystemMessage(_, msg)
    if msg and string.find(msg, " completed.") then
        self._ctx.lastQuestMsgAt = time()
    end
end

function Detect:OnInitialize()
  if L.LEGACY_MODE_ACTIVE then return end
  
  self:RegisterEvent("LOOT_OPENED", "OnLootOpened")
  self:RegisterEvent("LOOT_CLOSED", "OnLootClosed")
  
  self:RegisterEvent("BAG_UPDATE", "OnBagUpdate")

  
  self:RegisterEvent("GOSSIP_SHOW", function() self._ctx.lastGossipAt = time(); self:OnNPCInteraction() end)
  self:RegisterEvent("GOSSIP_CLOSED", function() self._ctx.lastGossipAt = time(); self._expectingItemUntil = GetTime() + ITEM_EXPECTATION_WINDOW end)
  self:RegisterEvent("MERCHANT_SHOW", function() self._ctx.lastMerchantAt = time(); self:OnNPCInteraction() end)
  self:RegisterEvent("MERCHANT_UPDATE", function() self._ctx.lastMerchantAt = time(); self:OnNPCInteraction() end)
  self:RegisterEvent("MERCHANT_CLOSED", function() self._ctx.lastMerchantAt = nil end)
  self:RegisterEvent("MAIL_SHOW", function() self._ctx.mailOpen = true end)
  self:RegisterEvent("MAIL_CLOSED", function()
      self._ctx.mailOpen = false
      self._ctx.mailClosedAt = time()
  end)
  self:RegisterEvent("CHAT_MSG_LOOT", "OnChatMsgLoot")
  
  self:RegisterEvent("QUEST_COMPLETE", function() self._ctx.lastQuestCompleteAt = time() end)
  self:RegisterEvent("QUEST_FINISHED", function() self._ctx.lastQuestFinishedAt = time() end)
  self:RegisterEvent("QUEST_TURNED_IN", function() self._ctx.lastQuestTurnedInAt = time() end)
  self:RegisterEvent("CHAT_MSG_SYSTEM", "OnSystemMessage")

  self:RegisterEvent("TRADE_SHOW", function() self._ctx.tradeOpen = true end)
  self:RegisterEvent("TRADE_CLOSED", function()
      self._ctx.tradeOpen = false
      self._ctx.lastTradeAcceptedAt = nil
      self._ctx.tradeClosedAt = time()
  end)
  self:RegisterEvent("TRADE_ACCEPTED", function() self._ctx.lastTradeAcceptedAt = time() end)
  self:RegisterEvent("TRADE_SKILL_SHOW", function() self._ctx.craftingOpen = true end)
  self:RegisterEvent("TRADE_SKILL_CLOSE", function() self._ctx.craftingOpen = false end)
  self:RegisterEvent("CRAFT_SHOW", function() self._ctx.craftingOpen = true end)
  self:RegisterEvent("CRAFT_CLOSE", function() self._ctx.craftingOpen = false end)
  
  self:RegisterEvent("BANK_FRAME_OPENED", function() self._ctx.bankOpen = true end)
  self:RegisterEvent("BANK_FRAME_CLOSED", function()
      self._ctx.bankOpen = false
      self._ctx.bankClosedAt = time()
  end)
  self:RegisterEvent("GUILDBANKFRAME_OPENED", function() self._ctx.guildBankOpen = true end)
  self:RegisterEvent("GUILDBANKFRAME_CLOSED", function()
      self._ctx.guildBankOpen = false
      self._ctx.guildBankClosedAt = time()
  end)
  self:RegisterEvent("ACHIEVEMENT_EARNED", function() self._ctx.lastAchievementAt = time() end)

  self:RegisterEvent("UI_INFO_MESSAGE", "OnRetroactiveSuppressionEvent")
  self:RegisterEvent("RECOVERY_RESULT", "OnRetroactiveSuppressionEvent")
  self:RegisterEvent("PURCHASE_CUSTOM_STORE_ITEM_RESULT", "OnRetroactiveSuppressionEvent")

  if hooksecurefunc then
    hooksecurefunc("TakeInboxItem", function() Detect._ctx.lastMailTakeAt = time() end)
    hooksecurefunc("DoEmote", function() Detect._ctx.lastEmoteAt = time() end)
    hooksecurefunc("BuybackItem", function() Detect._ctx.lastBuybackAt = time() end)
  end
end

local function classifySource(ctx, now)
  local QUEST_WINDOW = 30.0

  -- Linger after close: bag CHAT_MSG_LOOT often fires after the frame hides,
  -- and must still count as bank/mail/trade (never as world loot).
  if ctx.mailOpen or (ctx.lastMailTakeAt and (now - ctx.lastMailTakeAt <= 3))
      or (ctx.mailClosedAt and (now - ctx.mailClosedAt <= CONTAINER_LINGER)) then
      return "mail"
  end
  if ctx.tradeOpen or (ctx.lastTradeAcceptedAt and (now - ctx.lastTradeAcceptedAt <= 3))
      or (ctx.tradeClosedAt and (now - ctx.tradeClosedAt <= CONTAINER_LINGER)) then
      return "trade"
  end
  if ctx.bankOpen or (ctx.bankClosedAt and (now - ctx.bankClosedAt <= CONTAINER_LINGER)) then
      return "bank"
  end
  if ctx.guildBankOpen or (ctx.guildBankClosedAt and (now - ctx.guildBankClosedAt <= CONTAINER_LINGER)) then
      return "guild_bank"
  end
  
  if (ctx.lastQuestCompleteAt and (now - ctx.lastQuestCompleteAt <= 5)) or
     (ctx.lastQuestFinishedAt and (now - ctx.lastQuestFinishedAt <= QUEST_WINDOW)) or
     (ctx.lastQuestTurnedInAt and (now - ctx.lastQuestTurnedInAt <= QUEST_WINDOW)) or
     (ctx.lastQuestMsgAt and (now - ctx.lastQuestMsgAt <= QUEST_WINDOW)) then 
     return "quest_reward" 
  end

  if ctx.lastAchievementAt and (now - ctx.lastAchievementAt <= 3) then return "achievement" end
  if ctx.craftingOpen then return "crafting" end
  if _G.C_MysticEnchant and _G.C_MysticEnchant.HasNearbyMysticAltar and _G.C_MysticEnchant.HasNearbyMysticAltar() then return "mystic_altar" end
  if ctx.lastBuybackAt and (now - ctx.lastBuybackAt <= 3) then return "vendor_buyback" end
  if ctx.lastMerchantAt and (now - ctx.lastMerchantAt <= 5) then return "vendor" end
  if ctx.lastLootOpenedAt and (now - ctx.lastLootOpenedAt <= LOOT_VALIDITY_WINDOW) then return "world_loot" end
  if ctx.lastGossipAt and (now - ctx.lastGossipAt <= 5) then return "npc_gossip" end
  if ctx.lastEmoteAt and (now - ctx.lastEmoteAt <= 5) then return "emote_event" end
  return "direct"
end

local function ExtractLootLink(msg)
    if not msg then return nil end
    return msg:match("|Hitem:%-?%d+:[^|]*|h%[[^%]]+%]|h")
        or msg:match("|Hitem:(%d+)") and msg:match("|Hitem:%d+:[^|]*|h.-|h")
end

local function IsSelfLootMessage(msg)
    if not msg then return false end
    local clean = msg:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    if clean:find("^You receive", 1, true)
        or clean:find("^You create", 1, true)
        or clean:find("^You loot", 1, true)
        or clean:find("^You have looted", 1, true)
        or clean:find(" receive loot:", 1, true)
        or clean:find(" receives loot:", 1, true) then
        return true
    end
    local me = UnitName("player")
    if me and (clean:find("^" .. me .. " receives", 1, true) or clean:find("^" .. me .. " receive", 1, true)) then
        return true
    end
    return false
end

-- Grimfall/Ascension loot chat often embeds the unscaled base item link (no
-- "Worldforged" line). The bag copy has the real tooltip. Prefer that link.
local function FindBagLinkByItemID(itemID)
    itemID = tonumber(itemID)
    if not itemID then return nil end
    for bag = 0, 4 do
        local slots = GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            local bagLink = GetContainerItemLink(bag, slot)
            if bagLink then
                local id = tonumber(bagLink:match("item:(%-?%d+)"))
                if id == itemID then
                    return bagLink
                end
            end
        end
    end
    return nil
end

local function PreferBagLink(link)
    if not link then return link end
    local itemID = tonumber(link:match("item:(%-?%d+)"))
    if not itemID then return link end
    local bagLink = FindBagLinkByItemID(itemID)
    if bagLink and bagLink ~= link then
        return bagLink
    end
    return link
end

local function ResolveLootPosition(preferLootContext)
    local c, z, iz, x_val, y_val
    local nowTime = time()
    if preferLootContext and lastLootContext.openedAt and (nowTime - lastLootContext.openedAt) <= LOOT_VALIDITY_WINDOW then
        c, z, iz = lastLootContext.c, lastLootContext.z, lastLootContext.iz
        x_val, y_val = lastLootContext.x, lastLootContext.y
    end

    local needFresh = not c or not z or ((tonumber(x_val) or 0) == 0 and (tonumber(y_val) or 0) == 0)
    if needFresh then
        local Map = L:GetModule("Map", true)
        if Map and Map.GetPlayerLocation then
            local mc, mmapID, mpx, mpy = Map:GetPlayerLocation(true)
            if mmapID and mpx and mpy and (mpx > 0 or mpy > 0) then
                local ZoneList = L:GetModule("ZoneList", true)
                local zoneInfo = ZoneList and ZoneList.MapDataByID[mmapID]
                if zoneInfo then
                    c = zoneInfo.continentID
                    z = mmapID
                    iz = 0
                else
                    c = mc or GetCurrentMapContinent() or 0
                    z = mmapID
                    iz = mmapID
                end
                x_val, y_val = mpx, mpy
                needFresh = false
            end
        end
    end

    if needFresh then
        if SetMapToCurrentZone then SetMapToCurrentZone() end
        local mapID = GetCurrentMapAreaID()
        local ZoneList = L:GetModule("ZoneList", true)
        local zoneInfo = ZoneList and ZoneList.MapDataByID[mapID]
        if zoneInfo then
            c = zoneInfo.continentID
            z = mapID
            iz = 0
        else
            c = GetCurrentMapContinent() or 0
            z = mapID
            iz = mapID
        end
        local px, py = GetPlayerMapPosition("player")
        x_val, y_val = px or 0, py or 0
    end

    return c or 0, z or 0, iz or 0, x_val or 0, y_val or 0
end

function Detect:OnChatMsgLoot(_, msg)
    local pTime = L.ProfileStart and L:ProfileStart() 

    if L:IsPaused() then 
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end

    local Constants = L:GetModule("Constants", true)
    if Constants and Constants.ALLOW_PVP_INSTANCES == false then
        local isInstance, instanceType = IsInInstance()
        if isInstance and (instanceType == "pvp" or instanceType == "arena") then
            L._ddebug("Detect", "Dropped: Loot event occurred inside a PvP instance.")
            if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
            return
        end
    end
    L._ddebug("Detect", "OnChatMsgLoot fired: " .. tostring(msg))
    
    local link = ExtractLootLink(msg)
    if not link then 
        L._ddebug("Detect", "Dropped: No item link found in chat message.")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end

    local itemID = tonumber(link:match("item:(%-?%d+)"))
    local fromLootWindow = itemID and self._openLootItems and self._openLootItems[itemID]
    if not IsSelfLootMessage(msg) and not fromLootWindow then
        L._ddebug("Detect", "Ignored third-party loot chat.")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end
    local looter = UnitName("player")
    
    local nowTime = time()
    local src = classifySource(self._ctx, nowTime)
    L._ddebug("Detect", "Source originally classified as: " .. tostring(src))

    local deniedSources = {
        mail = true, quest_reward = true, trade = true, crafting = true,
        mystic_altar = true, vendor = true, vendor_buyback = true,
        bank = true, guild_bank = true, achievement = true,
    }
    if deniedSources[src] then 
        L._ddebug("Detect", "Dropped: Source is in denied list (" .. tostring(src) .. ")")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end

    -- WF pins may ONLY be created/moved from a real loot-window session.
    -- Bank/mail/trade/direct bag pops never get a LOOT_OPENED context, so they
    -- cannot relocate pins to Stormwind/org/etc.
    if not HasFreshWorldLootContext() then
        L._ddebug("Detect", "Dropped: no fresh LOOT_OPENED context (refusing non-world location).")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end
        return
    end
    src = "world_loot"

    local c = lastLootContext.c
    local z = lastLootContext.z
    local iz = lastLootContext.iz
    local x_val = lastLootContext.x
    local y_val = lastLootContext.y
    
    if Constants and Constants.IsForbiddenZone and Constants:IsForbiddenZone(c, z, looter) then
        L._ddebug("Detect", "Dropped: Looted inside a forbidden zone.")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return
    end

    -- Arm bag follow-up: chat link is often not WF-tagged; bag link is.
    self._expectingItemUntil = GetTime() + ITEM_EXPECTATION_WINDOW
    for bag = 0, 4 do
        self._dirtyBags[bag] = true
    end

    -- Swap to inventory link when possible before Qualifies().
    local resolved = PreferBagLink(link)
    if resolved ~= link then
        L._ddebug("Detect", "Using bag link instead of chat link for WF check.")
        link = resolved
        if self._cache and self._cache.isWF then
            self._cache.isWF[link] = nil
        end
    end

    local qualifies = self:Qualifies(link, src)

    -- Always arm pending with LOOT_OPENED coords so bag-tooltip confirmation
    -- cannot fall back to the player's later (city/bank) position.
    if qualifies ~= true and itemID then
        self._pendingBagLoot = self._pendingBagLoot or {}
        self._pendingBagLoot[itemID] = {
            chatLink = link,
            src = "world_loot",
            c = c, z = z, iz = iz,
            x = x_val, y = y_val,
            fp = looter,
            t0 = lastLootContext.openedAt or nowTime,
            tries = 0,
            fromLootWindow = true,
            allowCoordUpdate = true,
        }
        EnsurePendingTicker()
    end
    
    if qualifies == nil then
        L._ddebug("Detect", "Data not ready. Queueing cache request and delaying CHAT_MSG_LOOT evaluation.")
        if itemID then
            local Core = L:GetModule("Core", true)
            if Core and Core.QueueItemForCaching then
                Core:QueueItemForCaching(itemID)
                Core:EnsureCachePump()
            end
        end
        self._lootRetryCount = self._lootRetryCount or {}
        local retryKey = tostring(itemID or link)
        local retries = (self._lootRetryCount[retryKey] or 0) + 1
        self._lootRetryCount[retryKey] = retries
        if retries <= 5 then
            L:ScheduleAfter(0.5, function()
                self:OnChatMsgLoot(nil, msg)
            end)
        else
            self._lootRetryCount[retryKey] = nil
            L._ddebug("Detect", "Gave up waiting for item tooltip data: " .. tostring(link))
        end
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return
    elseif qualifies == false then
        L._ddebug("Detect", "Chat/base link not WF/MS yet; waiting on bag link resolver.")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end

    if self._lootRetryCount and itemID then self._lootRetryCount[tostring(itemID)] = nil end
    
    local last = self._recent[link] or (itemID and self._recent["id:" .. itemID]) or 0
    if nowTime - last < 1.0 then 
        L._ddebug("Detect", "Dropped: Throttled (Looted multiple in <1s).")
        if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
        return 
    end

    local committed = self:CommitLocalDiscovery(
        link, c, z, iz, x_val, y_val, lastLootContext.openedAt or nowTime, "world_loot", looter,
        { allowCoordUpdate = true }
    )
    if committed then
        self._recent[link] = nowTime
        if itemID then self._recent["id:" .. itemID] = nowTime end
        if itemID and self._pendingBagLoot then self._pendingBagLoot[itemID] = nil end
    end
    
    if pTime then L:ProfileStop("Detect:OnChatMsgLoot", pTime) end 
end

function Detect:CommitLocalDiscovery(link, c, z, iz, x, y, t0, src, looter, opts)
    if not link then return false end
    opts = opts or {}
    local itemID = tonumber(link:match("item:(%-?%d+)"))

    -- Coord updates require an explicit world-loot trust flag. Everything else
    -- (bank withdraw, bag reshuffle, mail, etc.) may not move pins.
    -- Freshness is always wall-clock against LOOT_OPENED (never use t0 as "now").
    local allowCoords = opts.allowCoordUpdate == true
        and src == "world_loot"
        and HasFreshWorldLootContext()
    if allowCoords then
        -- Always stamp the frozen loot-window position, never "where I am now".
        c, z, iz = lastLootContext.c, lastLootContext.z, lastLootContext.iz
        x, y = lastLootContext.x, lastLootContext.y
        t0 = lastLootContext.openedAt or t0
    end

    local discovery = {
        il = link, c = c, z = z, iz = iz,
        xy = { x = x, y = y }, t0 = t0 or time(),
        src = src, fp = looter or UnitName("player"),
        skipCoordUpdate = not allowCoords,
        worldLootTrusted = allowCoords,
    }
    local Core = L:GetModule("Core", true)
    local ok = false
    if Core and Core.HandleLocalLoot then
        local guid = L:GenerateGUID(c, z, iz, itemID, x, y)
        self._lastDiscoveryGUID = guid
        self._lastDiscoveryTime = GetTime()
        ok = Core:HandleLocalLoot(discovery) and true or false
        if discovery.g then
            self._lastDiscoveryGUID = discovery.g
        end
    end
    if not ok then return false end

    if itemID and L.MarkItemLooted then
        L:MarkItemLooted(itemID, self._lastDiscoveryGUID, { c = c, z = z })
    end

    local name = link:match("%[(.-)%]") or ("item " .. tostring(itemID))
    local zoneName = (L.ResolveZoneDisplay and L.ResolveZoneDisplay(c, z, iz)) or "Unknown"
    print(string.format("|cff00ff00LootCollector:|r Recorded |cffffffff%s|r @ %s (%.1f, %.1f).",
        name, zoneName, (x or 0) * 100, (y or 0) * 100))

    local Map = L:GetModule("Map", true)
    if Map then
        Map.cacheIsDirty = true
        L.DataHasChanged = true
        if Map.Update and WorldMapFrame and WorldMapFrame:IsShown() then Map:Update() end
        if Map.UpdateMinimap then Map:UpdateMinimap() end
    end

    if itemID then
        L:SendMessage("LOOTCOLLECTOR_PLAYER_LOOTED_ITEM", itemID, c, z, x, y)
    end
    return true
end

function Detect:ResolvePendingBagLoot()
    if not self._pendingBagLoot then return end
    local now = time()
    for itemID, pending in pairs(self._pendingBagLoot) do
        pending.tries = (pending.tries or 0) + 1

        -- Stale / non-loot-window pendings must never relocate pins.
        if not pending.fromLootWindow or pending.src ~= "world_loot" then
            self._pendingBagLoot[itemID] = nil
        elseif (not HasFreshWorldLootContext()) and (now - (pending.t0 or 0)) > LOOT_VALIDITY_WINDOW then
            self._pendingBagLoot[itemID] = nil
        else
            local bagLink = FindBagLinkByItemID(itemID)
            if bagLink then
                if self._cache and self._cache.isWF then
                    self._cache.isWF[bagLink] = nil
                end
                local qualifies = self:Qualifies(bagLink, "world_loot")
                if qualifies == true then
                    local committed = self:CommitLocalDiscovery(
                        bagLink,
                        pending.c, pending.z, pending.iz,
                        pending.x, pending.y, pending.t0,
                        "world_loot", pending.fp,
                        { allowCoordUpdate = true }
                    )
                    if committed then
                        self._recent[bagLink] = now
                        self._recent["id:" .. itemID] = now
                        self._pendingBagLoot[itemID] = nil
                    elseif pending.tries >= 12 then
                        self._pendingBagLoot[itemID] = nil
                    end
                elseif qualifies == false then
                    -- Definitive non-WF/MS (normal loot in the window).
                    if pending.tries >= 4 then
                        self._pendingBagLoot[itemID] = nil
                    end
                end
            elseif pending.tries >= 14 then
                self._pendingBagLoot[itemID] = nil
            end
        end
    end
end

function Detect:ProcessPotentialDiscovery(link, sourceHint, looterName)
    local pTime = L.ProfileStart and L:ProfileStart() 

    -- Legacy entry point: never used for bag scans anymore. Keep a hard gate
    -- so any future caller cannot relocate WF pins without a loot window.
    if L:IsPaused() or sourceHint == "bag_update" then
        if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
        return
    end
    if not HasFreshWorldLootContext() then
        if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
        return
    end

    local Constants = L:GetModule("Constants", true)
    if Constants and Constants.ALLOW_PVP_INSTANCES == false then
        local isInstance, instanceType = IsInInstance()
        if isInstance and (instanceType == "pvp" or instanceType == "arena") then
            if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
            return
        end
    end

    local nowTime = time()
    looterName = looterName or UnitName("player")
    local src = classifySource(self._ctx, nowTime)
    local deniedSources = {
        mail = true, quest_reward = true, trade = true, crafting = true,
        mystic_altar = true, vendor = true, vendor_buyback = true,
        bank = true, guild_bank = true, achievement = true,
    }
    if deniedSources[src] then
        if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
        return
    end

    link = PreferBagLink(link)
    local isWF = self:IsWorldforged(link)
    local isMS = self:IsMysticScroll(link, "world_loot")
    if not isWF and not isMS then
        if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
        return
    end

    local itemID = tonumber(link:match("item:(%-?%d+)"))
    if itemID and L.IsItemLootedByCurrentChar and L:IsItemLootedByCurrentChar(itemID) then
        if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
        return
    end

    self:CommitLocalDiscovery(
        link,
        lastLootContext.c, lastLootContext.z, lastLootContext.iz,
        lastLootContext.x, lastLootContext.y, lastLootContext.openedAt,
        "world_loot", looterName,
        { allowCoordUpdate = true }
    )

    if pTime then L:ProfileStop("Detect:ProcessPotentialDiscovery", pTime) end
end

local function ProcessDirtyBags()
    local pTime = L.ProfileStart and L:ProfileStart() 

    Detect._bagUpdateTimer = nil
    if L:IsPaused() then 
        if pTime then L:ProfileStop("Detect:ProcessDirtyBags", pTime) end 
        return 
    end

    -- Only resolve itemIDs explicitly pending from a loot chat event.
    -- Scanning every WF still sitting in bags re-ran HandleLocalLoot and
    -- snapped ALL of their map pins to the player's current spot.
    wipe(Detect._dirtyBags)
    if Detect.ResolvePendingBagLoot then
        Detect:ResolvePendingBagLoot()
    end
    
    if pTime then L:ProfileStop("Detect:ProcessDirtyBags", pTime) end 
end

function Detect:OnBagUpdate(event, bagID)
    if bagID == nil then
        for bag = 0, 4 do self._dirtyBags[bag] = true end
    else
        self._dirtyBags[bagID] = true
    end
    if not self._bagUpdateTimer then
        if type(C_Timer) == "table" and type(C_Timer.After) == "function" then
            self._bagUpdateTimer = C_Timer.After(0.2, ProcessDirtyBags)
        else
            ProcessDirtyBags()
        end
    end
end

return Detect